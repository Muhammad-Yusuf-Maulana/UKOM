<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vendor/css/bootstrap.css">
    <title><?= $judul; ?></title>
    <link rel="stylesheet" href="<?= base_url(); ?>assets/css/style.css">
    <!-- <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/home/style.css">  -->
</head>
<body style="margin:0; padding:0;">
    <!-- <div id="main"> -->
    <div class="main-home">
       <div class="filter">
                        <center>
            <div class="box-form">
                <form action="">
                    <div class="form-login p-5">
                        <div class="text-center">
                            <h2><b>SIGN IN</b></h2>
                        </div>
                        <div class="mt-3 shadow-sm">
                            <!-- <span>USERNAME</span> -->
                            <input class="form-control" type="text" name="nama" placeholder="USERNAME" required="required">
                        </div>
                        <div class="mt-3 shadow-sm">
                            <!-- <span>PASSWORD</span> -->
                            <input class="form-control" type="text" name="nama" placeholder="PASSWORD" required="required">
                        </div>
                        <div class="d-flex justify-content-end mt-4">
                            <button type="button" class="btn text-light btn-apes">SUBMIT</button>
                        </div>
                        <!-- <div class="d-flex justify-content-end mt-4">
                            <button type="button" class="btn text-white font-weight-bold" style="background-color: #7189FF !important;">SUBMIT</button>
                        </div> -->
                    </div>
                </form>
            </div>        
                        </center>
       </div> 
    </div>
</body>
</html>