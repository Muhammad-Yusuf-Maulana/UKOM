<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vendor/css/bootstrap.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vendor/js/bootstrap.js">
    <title><?= $judul; ?></title>
    <link rel="stylesheet" href="<?= base_url(); ?>assets/css/style.css">

    <!-- <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/home/style.css">  -->
<!-- </head> -->
<!-- <body style="margin:0; padding:0;"> -->
<!-- <style>
body {
  font-family: "Lato", sans-serif;
} 

</style> -->
</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn coba" onclick="closeNav()">&times;</a>
  <a href="#">About</a>
  <a href="#">Services</a>
  <a href="#">Clients</a>
  <a href="#">Contact</a>
</div>


