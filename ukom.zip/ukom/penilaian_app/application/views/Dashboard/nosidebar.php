<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?= $judul ?></title>
    <link rel="stylesheet" href="<?= base_url(); ?>assets/css/style.css">
    <link href="<?= base_url() ?>assets/vendor/fontawesome-free-5.12.0-web/css/fontawesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url() ?>assets/vendor/fontawesome-free-5.12.0-web/css/all.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vendor/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vendor/js/bootstrap.min.js">
    <style>
        .bg-apes-primary {
            background-color: #7189FF;
        }

        .bg-apes-secondary {
            background-color: #c1cefe;
        }

        .btn-apes {
            background-color: #c1cefe;
            color: #fff;
        }

        .btn-apes:hover {
            color: #fff;
        }

        .apes-link {
            color: #fff;
            transition: 0.2s;
        }

        .apes-link:hover {
            color: #fff;
            transform: scale(1.2);
        }

        .apes-active-link {
            transform: scale(1.2);
        }
    </style>
</head>

<body>
    <nav class="navbar bg-apes-primary">
        <div class="container">
            <div class="mx-2">
                <a href="#" class="fas fa-user-circle fa-3x"></a>
            </div>
            <div class="mr-auto text-light">
                <p class="p-0 m-0 font-weight-bolder">Aldi Maulana</p>
                <p class="p-0 m-0 font-weight-lighter">Admin</p>
            </div>
            <form method="post" class="d-none d-md-block">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search...">
                    <div class=" input-group-append">
                        <button class="btn btn-apes">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </nav>
    <nav class="navbar sticky-top bg-apes-secondary">
        <div class="container justify-content-center">
            <ul class="nav">
                <li class="nav-item">
                    <a href="#" class="nav-link apes-link apes-active-link">Home</a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link apes-link">Jurusan</a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link apes-link">Kelas</a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link apes-link">Mata Pelajaran</a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link apes-link">Pengguna</a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link apes-link">Nilai</a>
                </li>
            </ul>
        </div>
    </nav>
    <div class="container">
    </div>
</body>

</html>