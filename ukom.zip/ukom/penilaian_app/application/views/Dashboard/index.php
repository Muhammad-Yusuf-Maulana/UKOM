<div id="main-dashboard">
    <div class="dashboard-navbar d-flex justify-content-between">
        <span onclick="openNav()">☰</span>
        <a  data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample" class="profile bg-dark d-flex justify-content-between">
            <div class="box-foto d-flex align-items-center justify-content-center bg-success">
                <img src="<?= base_url(); ?>assets/img/logo.png" style="width: 50px;" alt="">
            </div>
            <div class="box-nama d-flex align-items-center p-2 bg-warning">username</div>
        </a>
    </div>
    <div class="box-collapse bg-dark p-2" id="collapseExample">
        <div class="collapse-top bg-primary">
            Anim pariatur cliche reprehender
        </div>
        <div class="collapse-bottom d-flex justify-content-between bg-success">
            <a href="#" class="btn btn-danger">LOG out</a>
            <a href="#" class="btn btn-apes">Profile</a>
        </div>
    </div>
    <div class="dashboard-content">
        <div class="d-flex justify-content-center flex-wrap">
            <div class="box-fitur m-5">
                
            </div>
            <div class="box-fitur m-5">
                 
            </div>
        </div>
        <div class="d-flex justify-content-center flex-wrap">
            <div class="box-fitur m-5">
                
            </div>
            <div class="box-fitur m-5">
                
            </div>
        </div>
    </div>
    <div class="dashboard-footer d-flex align-items-center justify-content-center bg-primary">
        FOOTER
    </div>
</div> 