<div id="main-dashboard">
    <div class="dashboard-navbar d-flex justify-content-between">
        <span onclick="openNav()">☰</span>
        <a href="#" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample" class="profile bg-dark d-flex justify-content-between">
            <div class="box-foto bg-success">1</div>
            <div class="box-nama bg-warning">2</div>
        </a>
        <div class="collapse" id="collapseExample">
            <div class="card card-body">
                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
            </div>
        </div>
    </div>
    <div class="dashboard-content">
        <div class="d-flex justify-content-center flex-wrap">
            <div class="box-fitur m-5">
                
            </div>
            <div class="box-fitur m-5">
                
            </div>
        </div>
        <div class="d-flex justify-content-center flex-wrap">
            <div class="box-fitur m-5">
                
            </div>
            <div class="box-fitur m-5">
                
            </div>
        </div>
    </div>
    <div class="dashboard-footer d-flex align-items-center justify-content-center bg-primary">
        FOOTER
    </div>
</div>