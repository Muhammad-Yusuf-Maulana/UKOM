<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function index()
	{
        $data['judul'] = "DASHBOARD | ...";
		$this->load->view('Template/sidebar', $data);
		$this->load->view('Dashboard/index', $data);
		$this->load->view('Template/footer', $data);
	}

	public function nosidebar()
	{
		$data['judul'] = "DASHBOARD | No SideBar";
		$this->load->view('Dashboard/nosidebar', $data);
		$this->load->view('Template/footer', $data);
	}
}
 