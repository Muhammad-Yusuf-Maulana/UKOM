<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jurusan extends CI_Controller {

	public function index()
	{
        $data['judul'] = "List Jurusan | APES";

        $this->load->view('Template/sidebar', $data);
        $this->load->view('Jurusan/index');
        $this->load->view('Template/footer');
	}
}
