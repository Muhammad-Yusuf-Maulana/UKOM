<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    public function index()
	{
        $data['judul'] = " HOMEPAGE | PMP ";
        
		$this->load->view('Homepage/index', $data);
    }

    // public function auth()
    // {

    // }
}
