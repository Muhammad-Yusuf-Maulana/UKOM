-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 24, 2020 at 07:44 AM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_ukom_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_bidstud`
--

DROP TABLE IF EXISTS `tb_bidstud`;
CREATE TABLE `tb_bidstud` (
  `id` int(11) NOT NULL,
  `kode` varchar(5) NOT NULL,
  `nama` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_bidstud`
--

INSERT INTO `tb_bidstud` (`id`, `kode`, `nama`) VALUES
(1, 'TI', 'Teknologi Informasi');

-- --------------------------------------------------------

--
-- Table structure for table `tb_guru`
--

DROP TABLE IF EXISTS `tb_guru`;
CREATE TABLE `tb_guru` (
  `id` int(11) NOT NULL,
  `nip` varchar(18) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `id_mapel` int(11) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `id_jurusan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_guru`
--

INSERT INTO `tb_guru` (`id`, `nip`, `nama`, `alamat`, `id_mapel`, `id_kelas`, `id_jurusan`) VALUES
(1, '200223042018041024', 'Aldi Maulana Iqbal', 'Jl. Kenangan No. 69', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_jurusan`
--

DROP TABLE IF EXISTS `tb_jurusan`;
CREATE TABLE `tb_jurusan` (
  `id` int(11) NOT NULL,
  `kode` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `id_bidstud` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_jurusan`
--

INSERT INTO `tb_jurusan` (`id`, `kode`, `nama`, `id_bidstud`) VALUES
(1, 'RPL', 'Rekayasa Perangkat Lunak', 1),
(2, 'MM', 'Multimedia', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_kelas`
--

DROP TABLE IF EXISTS `tb_kelas`;
CREATE TABLE `tb_kelas` (
  `id` int(11) NOT NULL,
  `nama` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_kelas`
--

INSERT INTO `tb_kelas` (`id`, `nama`) VALUES
(1, 'X'),
(2, 'XI'),
(3, 'XII');

-- --------------------------------------------------------

--
-- Table structure for table `tb_level`
--

DROP TABLE IF EXISTS `tb_level`;
CREATE TABLE `tb_level` (
  `id` int(11) NOT NULL,
  `level` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_level`
--

INSERT INTO `tb_level` (`id`, `level`) VALUES
(1, 'Administrator'),
(2, 'Guru'),
(3, 'Murid');

-- --------------------------------------------------------

--
-- Table structure for table `tb_mapel`
--

DROP TABLE IF EXISTS `tb_mapel`;
CREATE TABLE `tb_mapel` (
  `id` int(11) NOT NULL,
  `kode` varchar(3) NOT NULL,
  `nama` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_mapel`
--

INSERT INTO `tb_mapel` (`id`, `kode`, `nama`) VALUES
(1, 'MTK', 'Matematika'),
(2, 'BI', 'Bahasa Inggris'),
(3, 'BS', 'Bahasa Sunda');

-- --------------------------------------------------------

--
-- Table structure for table `tb_mapeljurusankelas`
--

DROP TABLE IF EXISTS `tb_mapeljurusankelas`;
CREATE TABLE `tb_mapeljurusankelas` (
  `id` int(11) NOT NULL,
  `id_jurusan` int(11) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `id_mapel` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_mapeljurusankelas`
--

INSERT INTO `tb_mapeljurusankelas` (`id`, `id_jurusan`, `id_kelas`, `id_mapel`) VALUES
(1, 1, 3, 1),
(2, 1, 3, 3),
(3, 2, 1, 2),
(4, 2, 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `tb_murid`
--

DROP TABLE IF EXISTS `tb_murid`;
CREATE TABLE `tb_murid` (
  `id` varchar(20) NOT NULL,
  `nisn` varchar(10) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `tempat_lahir` varchar(255) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `id_jurusan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_murid`
--

INSERT INTO `tb_murid` (`id`, `nisn`, `nama`, `foto`, `alamat`, `tempat_lahir`, `tanggal_lahir`, `id_kelas`, `id_jurusan`) VALUES
('5e2a54efecc3fefecc40', '1829456328', 'Booby', '1829456328.jpg', 'Jl. Jalan Yuk No. 99', 'Magetan', '2009-07-03', 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_nilai`
--

DROP TABLE IF EXISTS `tb_nilai`;
CREATE TABLE `tb_nilai` (
  `id` int(11) NOT NULL,
  `nilai_pengetahuan` tinyint(4) NOT NULL,
  `nilai_keterampilan` tinyint(4) NOT NULL,
  `nh_pengetahuan` varchar(1) NOT NULL,
  `nh_keterampilan` varchar(1) NOT NULL,
  `jenis` varchar(255) NOT NULL,
  `tahun ajaran` varchar(255) NOT NULL,
  `id_sub_mapel` int(11) NOT NULL,
  `id_guru` int(11) NOT NULL,
  `id_murid` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_nohp_walmur`
--

DROP TABLE IF EXISTS `tb_nohp_walmur`;
CREATE TABLE `tb_nohp_walmur` (
  `id` int(11) NOT NULL,
  `nomor` varchar(15) NOT NULL,
  `id_walmur` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_nohp_walmur`
--

INSERT INTO `tb_nohp_walmur` (`id`, `nomor`, `id_walmur`) VALUES
(5, '081285859696', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_sub_mapel`
--

DROP TABLE IF EXISTS `tb_sub_mapel`;
CREATE TABLE `tb_sub_mapel` (
  `id` int(11) NOT NULL,
  `kode` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `id_mapel` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

DROP TABLE IF EXISTS `tb_user`;
CREATE TABLE `tb_user` (
  `id` varchar(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `id_level` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id`, `username`, `password`, `id_level`, `created_at`) VALUES
('5e2a502f72b2c2f72b2d', 'admin', 'admin', 1, '2020-01-24 02:04:08');

-- --------------------------------------------------------

--
-- Table structure for table `tb_walmur`
--

DROP TABLE IF EXISTS `tb_walmur`;
CREATE TABLE `tb_walmur` (
  `id` int(11) NOT NULL,
  `nama_ayah` varchar(255) NOT NULL,
  `nama_ibu` varchar(255) NOT NULL,
  `pekerjaan_ayah` varchar(255) NOT NULL,
  `pekerjaan_ibu` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `id_murid` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_walmur`
--

INSERT INTO `tb_walmur` (`id`, `nama_ayah`, `nama_ibu`, `pekerjaan_ayah`, `pekerjaan_ibu`, `alamat`, `id_murid`) VALUES
(1, 'Joko', 'Siti', 'Karyawan', 'Lonte', 'Disono', '5e2a54efecc3fefecc40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_bidstud`
--
ALTER TABLE `tb_bidstud`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_guru`
--
ALTER TABLE `tb_guru`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nip` (`nip`),
  ADD KEY `fk_guru_kelas` (`id_kelas`),
  ADD KEY `fk_guru_jurusan` (`id_jurusan`),
  ADD KEY `fk_guru_mapel` (`id_mapel`);

--
-- Indexes for table `tb_jurusan`
--
ALTER TABLE `tb_jurusan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_jurusan_bidstud` (`id_bidstud`);

--
-- Indexes for table `tb_kelas`
--
ALTER TABLE `tb_kelas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nama` (`nama`);

--
-- Indexes for table `tb_level`
--
ALTER TABLE `tb_level`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_mapel`
--
ALTER TABLE `tb_mapel`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode` (`kode`);

--
-- Indexes for table `tb_mapeljurusankelas`
--
ALTER TABLE `tb_mapeljurusankelas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_mapeljurusankelas_1` (`id_jurusan`),
  ADD KEY `fk_mapeljurusankelas_2` (`id_kelas`),
  ADD KEY `fk_mapeljurusankelas_3` (`id_mapel`);

--
-- Indexes for table `tb_murid`
--
ALTER TABLE `tb_murid`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nisn` (`nisn`),
  ADD KEY `fk_murid_kelas` (`id_kelas`),
  ADD KEY `fk_murid_jurusan` (`id_jurusan`);

--
-- Indexes for table `tb_nilai`
--
ALTER TABLE `tb_nilai`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_nohp_walmur`
--
ALTER TABLE `tb_nohp_walmur`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_walmur_nohp` (`id_walmur`);

--
-- Indexes for table `tb_sub_mapel`
--
ALTER TABLE `tb_sub_mapel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_level` (`id_level`);

--
-- Indexes for table `tb_walmur`
--
ALTER TABLE `tb_walmur`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_murid` (`id_murid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_bidstud`
--
ALTER TABLE `tb_bidstud`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_guru`
--
ALTER TABLE `tb_guru`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_jurusan`
--
ALTER TABLE `tb_jurusan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_kelas`
--
ALTER TABLE `tb_kelas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_level`
--
ALTER TABLE `tb_level`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_mapel`
--
ALTER TABLE `tb_mapel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_mapeljurusankelas`
--
ALTER TABLE `tb_mapeljurusankelas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tb_nilai`
--
ALTER TABLE `tb_nilai`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_nohp_walmur`
--
ALTER TABLE `tb_nohp_walmur`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tb_sub_mapel`
--
ALTER TABLE `tb_sub_mapel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_walmur`
--
ALTER TABLE `tb_walmur`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_guru`
--
ALTER TABLE `tb_guru`
  ADD CONSTRAINT `fk_guru_jurusan` FOREIGN KEY (`id_jurusan`) REFERENCES `tb_jurusan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_guru_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `tb_kelas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_guru_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `tb_mapel` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_jurusan`
--
ALTER TABLE `tb_jurusan`
  ADD CONSTRAINT `fk_jurusan_bidstud` FOREIGN KEY (`id_bidstud`) REFERENCES `tb_bidstud` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_mapeljurusankelas`
--
ALTER TABLE `tb_mapeljurusankelas`
  ADD CONSTRAINT `fk_mapeljurusankelas_1` FOREIGN KEY (`id_jurusan`) REFERENCES `tb_jurusan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_mapeljurusankelas_2` FOREIGN KEY (`id_kelas`) REFERENCES `tb_kelas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_mapeljurusankelas_3` FOREIGN KEY (`id_mapel`) REFERENCES `tb_mapel` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_murid`
--
ALTER TABLE `tb_murid`
  ADD CONSTRAINT `fk_murid_jurusan` FOREIGN KEY (`id_jurusan`) REFERENCES `tb_jurusan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_murid_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `tb_kelas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_nohp_walmur`
--
ALTER TABLE `tb_nohp_walmur`
  ADD CONSTRAINT `fk_walmur_nohp` FOREIGN KEY (`id_walmur`) REFERENCES `tb_walmur` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD CONSTRAINT `fk_user_level` FOREIGN KEY (`id_level`) REFERENCES `tb_level` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_walmur`
--
ALTER TABLE `tb_walmur`
  ADD CONSTRAINT `fk_walmur_murid` FOREIGN KEY (`id_murid`) REFERENCES `tb_murid` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
