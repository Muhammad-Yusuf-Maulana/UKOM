-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 23 Feb 2020 pada 08.11
-- Versi server: 10.1.34-MariaDB
-- Versi PHP: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bnsp_ukom_rpl_1718_05_25`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `nohp_walmur`
--

CREATE TABLE `nohp_walmur` (
  `id` int(11) NOT NULL,
  `id_walmur` varchar(20) NOT NULL,
  `nomor` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_bidang_studi`
--

CREATE TABLE `tb_bidang_studi` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_bidang_studi`
--

INSERT INTO `tb_bidang_studi` (`id`, `name`) VALUES
(1, 'INFORMATIKA');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_guru`
--

CREATE TABLE `tb_guru` (
  `id` varchar(20) NOT NULL,
  `id_mapel` int(11) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `id_jurusan` int(11) NOT NULL,
  `id_user` varchar(20) NOT NULL,
  `nip` int(18) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_guru`
--

INSERT INTO `tb_guru` (`id`, `id_mapel`, `id_kelas`, `id_jurusan`, `id_user`, `nip`, `nama`, `foto`, `alamat`) VALUES
('asdasd', 1, 1, 1, 'dad21423', 987654321, 'PAK GURU mtk1', 'uploads/asdasd2.png', 'saaasaa'),
('wokkowkow', 2, 2, 2, 'erd', 12345679, 'PAK GURU AGAMA 1', 'user.png', 'http://localhost:8080/phpmyadmin/db_designer.php?db=bnsp_ukom_rpl_1718_05_25');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_jurusan`
--

CREATE TABLE `tb_jurusan` (
  `id` int(11) NOT NULL,
  `id_bidstud` int(11) NOT NULL,
  `kode` varchar(5) NOT NULL,
  `nama` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_jurusan`
--

INSERT INTO `tb_jurusan` (`id`, `id_bidstud`, `kode`, `nama`) VALUES
(1, 1, 'RPL', 'Rekayasa Perangkat Lunak'),
(2, 1, 'MM', 'Multimedia');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_kelas`
--

CREATE TABLE `tb_kelas` (
  `id` int(11) NOT NULL,
  `nama` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_kelas`
--

INSERT INTO `tb_kelas` (`id`, `nama`) VALUES
(1, '10'),
(2, '11'),
(3, '12');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_level`
--

CREATE TABLE `tb_level` (
  `id` int(11) NOT NULL,
  `level` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_level`
--

INSERT INTO `tb_level` (`id`, `level`) VALUES
(1, 'Administrator'),
(2, 'Guru'),
(3, 'Murid');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_mapel`
--

CREATE TABLE `tb_mapel` (
  `id` int(11) NOT NULL,
  `kode` varchar(5) NOT NULL,
  `nama` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_mapel`
--

INSERT INTO `tb_mapel` (`id`, `kode`, `nama`) VALUES
(1, 'MTK', 'Matematika'),
(2, 'PAI', 'Pendidikan Agama Islam');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_mapelkelasjurusan`
--

CREATE TABLE `tb_mapelkelasjurusan` (
  `id` int(11) NOT NULL,
  `id_mapel` int(11) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `id_jurusan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_mapelkelasjurusan`
--

INSERT INTO `tb_mapelkelasjurusan` (`id`, `id_mapel`, `id_kelas`, `id_jurusan`) VALUES
(1, 1, 1, 1),
(2, 2, 2, 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_murid`
--

CREATE TABLE `tb_murid` (
  `id` varchar(20) NOT NULL,
  `id_jurusan` int(11) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `id_user` varchar(255) NOT NULL,
  `nisn` int(10) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `tempat_lahir` varchar(255) NOT NULL,
  `tanggal_lahir` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_murid`
--

INSERT INTO `tb_murid` (`id`, `id_jurusan`, `id_kelas`, `id_user`, `nisn`, `nama`, `foto`, `alamat`, `tempat_lahir`, `tanggal_lahir`) VALUES
('lol', 1, 1, 'sadsa124', 987654321, 'murid pertama', 'user.png', 'http://localhost:8080/phpmyadmin/tbl_change.php?db=bnsp_ukom_rpl_1718_05_25&table=tb_murid', 'Jakarta', '2020-02-10'),
('mnb', 1, 1, 'wkwkwkkwk', 678905432, 'murid kedua', 'user.png', 'http://localhost/phpmyadmin/tbl_change.php?db=bnsp_ukom_rpl_1718_05_25&table=tb_murid', 'Jakarta', '2020-02-15');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_nilai`
--

CREATE TABLE `tb_nilai` (
  `id` int(11) NOT NULL,
  `id_sub_mapel` int(11) NOT NULL,
  `id_guru` varchar(20) NOT NULL,
  `id_murid` varchar(20) NOT NULL,
  `nilai_pengetahuan` tinyint(3) NOT NULL,
  `nilai_keterampilan` tinyint(3) NOT NULL,
  `nh_pengetahuan` varchar(2) NOT NULL,
  `nh_keterampilan` varchar(2) NOT NULL,
  `jenis` varchar(255) NOT NULL,
  `tahun_ajaran` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_nilai`
--

INSERT INTO `tb_nilai` (`id`, `id_sub_mapel`, `id_guru`, `id_murid`, `nilai_pengetahuan`, `nilai_keterampilan`, `nh_pengetahuan`, `nh_keterampilan`, `jenis`, `tahun_ajaran`) VALUES
(4, 1, 'asdasd', 'lol', 80, 80, 'B', 'B', 'ULHAR', '2019'),
(5, 1, 'asdasd', 'lol', 80, 80, 'B', 'B', 'PTS', '2019');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_sub_mapel`
--

CREATE TABLE `tb_sub_mapel` (
  `id` int(11) NOT NULL,
  `id_mapel` int(11) NOT NULL,
  `kode` varchar(5) NOT NULL,
  `nama` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_sub_mapel`
--

INSERT INTO `tb_sub_mapel` (`id`, `id_mapel`, `kode`, `nama`) VALUES
(1, 1, 'INT', 'Integral'),
(2, 2, 'Doa', 'Dzikir Pagi dan Petang'),
(3, 1, 'LOG', 'Logaritma');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_user`
--

CREATE TABLE `tb_user` (
  `id` varchar(20) NOT NULL,
  `id_level` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_user`
--

INSERT INTO `tb_user` (`id`, `id_level`, `username`, `password`, `created_at`) VALUES
('176hdkauskkshdhsna12', 1, 'admin', 'admin', '2020-02-13 08:13:25'),
('dad21423', 2, 'guru1', 'guru1', '2020-02-14 03:09:12'),
('erd', 2, 'guru2', 'guru2', '2020-02-14 04:07:26'),
('sadsa124', 3, 'murid1', 'murid1', '2020-02-14 03:09:12'),
('wkwkwkkwk', 3, 'murid2', 'murid2', '2020-02-14 04:01:52');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_walmur`
--

CREATE TABLE `tb_walmur` (
  `id` varchar(20) NOT NULL,
  `id_murid` varchar(20) NOT NULL,
  `nama_ayah` varchar(255) NOT NULL,
  `nama_ibu` varchar(255) NOT NULL,
  `pekerjaan_ayah` varchar(255) NOT NULL,
  `pekerjaan_ibu` varchar(255) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `v_nilai`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `v_nilai` (
`id_jurusan` int(11)
,`id_bidstud` int(11)
,`kode` varchar(5)
,`nama_jurusan` varchar(255)
,`id_kelas` int(11)
,`nama_kelas` varchar(5)
,`id_murid` varchar(20)
,`id_user_murid` varchar(255)
,`nisn` int(10)
,`nama_murid` varchar(255)
,`foto_murid` varchar(255)
,`alamat_murid` text
,`tempat_lahir` varchar(255)
,`tanggal_lahir` date
,`id_guru` varchar(20)
,`id_user_guru` varchar(20)
,`nip` int(18)
,`nama_guru` varchar(255)
,`foto_guru` varchar(255)
,`alamat_guru` text
,`id_nilai` int(11)
,`id_sub_mapel` int(11)
,`nilai_pengetahuan` tinyint(3)
,`nilai_keterampilan` tinyint(3)
,`nh_pengetahuan` varchar(2)
,`nh_keterampilan` varchar(2)
,`jenis` varchar(255)
,`tahun_ajaran` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `v_profile_guru`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `v_profile_guru` (
`id` varchar(20)
,`id_mapel` int(11)
,`id_kelas` int(11)
,`id_jurusan` int(11)
,`id_user` varchar(20)
,`nip` int(18)
,`nama` varchar(255)
,`foto` varchar(255)
,`alamat` text
,`username` varchar(255)
,`password` varchar(255)
,`id_level` int(11)
,`level` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `v_profile_murid`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `v_profile_murid` (
`id` varchar(20)
,`id_jurusan` int(11)
,`id_kelas` int(11)
,`id_user` varchar(255)
,`nisn` int(10)
,`nama` varchar(255)
,`foto` varchar(255)
,`alamat` text
,`tempat_lahir` varchar(255)
,`tanggal_lahir` date
,`username` varchar(255)
,`password` varchar(255)
,`id_level` int(11)
,`level` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `v_user`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `v_user` (
`user_id` varchar(20)
,`username` varchar(255)
,`password` varchar(255)
,`level` varchar(255)
);

-- --------------------------------------------------------

--
-- Struktur untuk view `v_nilai`
--
DROP TABLE IF EXISTS `v_nilai`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_nilai`  AS  select `tb_jurusan`.`id` AS `id_jurusan`,`tb_jurusan`.`id_bidstud` AS `id_bidstud`,`tb_jurusan`.`kode` AS `kode`,`tb_jurusan`.`nama` AS `nama_jurusan`,`tb_kelas`.`id` AS `id_kelas`,`tb_kelas`.`nama` AS `nama_kelas`,`tb_murid`.`id` AS `id_murid`,`tb_murid`.`id_user` AS `id_user_murid`,`tb_murid`.`nisn` AS `nisn`,`tb_murid`.`nama` AS `nama_murid`,`tb_murid`.`foto` AS `foto_murid`,`tb_murid`.`alamat` AS `alamat_murid`,`tb_murid`.`tempat_lahir` AS `tempat_lahir`,`tb_murid`.`tanggal_lahir` AS `tanggal_lahir`,`tb_guru`.`id` AS `id_guru`,`tb_guru`.`id_user` AS `id_user_guru`,`tb_guru`.`nip` AS `nip`,`tb_guru`.`nama` AS `nama_guru`,`tb_guru`.`foto` AS `foto_guru`,`tb_guru`.`alamat` AS `alamat_guru`,`tb_nilai`.`id` AS `id_nilai`,`tb_nilai`.`id_sub_mapel` AS `id_sub_mapel`,`tb_nilai`.`nilai_pengetahuan` AS `nilai_pengetahuan`,`tb_nilai`.`nilai_keterampilan` AS `nilai_keterampilan`,`tb_nilai`.`nh_pengetahuan` AS `nh_pengetahuan`,`tb_nilai`.`nh_keterampilan` AS `nh_keterampilan`,`tb_nilai`.`jenis` AS `jenis`,`tb_nilai`.`tahun_ajaran` AS `tahun_ajaran` from ((((`tb_jurusan` join `tb_murid` on((`tb_jurusan`.`id` = `tb_murid`.`id_jurusan`))) join `tb_kelas` on((`tb_murid`.`id_kelas` = `tb_kelas`.`id`))) join `tb_guru` on((`tb_guru`.`id_kelas` = `tb_kelas`.`id`))) join `tb_nilai` on((`tb_nilai`.`id_guru` = `tb_nilai`.`id_guru`))) ;

-- --------------------------------------------------------

--
-- Struktur untuk view `v_profile_guru`
--
DROP TABLE IF EXISTS `v_profile_guru`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_profile_guru`  AS  select `tb_guru`.`id` AS `id`,`tb_guru`.`id_mapel` AS `id_mapel`,`tb_guru`.`id_kelas` AS `id_kelas`,`tb_guru`.`id_jurusan` AS `id_jurusan`,`tb_guru`.`id_user` AS `id_user`,`tb_guru`.`nip` AS `nip`,`tb_guru`.`nama` AS `nama`,`tb_guru`.`foto` AS `foto`,`tb_guru`.`alamat` AS `alamat`,`tb_user`.`username` AS `username`,`tb_user`.`password` AS `password`,`tb_level`.`id` AS `id_level`,`tb_level`.`level` AS `level` from ((`tb_guru` join `tb_user` on((`tb_guru`.`id_user` = `tb_user`.`id`))) join `tb_level` on((`tb_level`.`id` = `tb_user`.`id_level`))) ;

-- --------------------------------------------------------

--
-- Struktur untuk view `v_profile_murid`
--
DROP TABLE IF EXISTS `v_profile_murid`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_profile_murid`  AS  select `tb_murid`.`id` AS `id`,`tb_murid`.`id_jurusan` AS `id_jurusan`,`tb_murid`.`id_kelas` AS `id_kelas`,`tb_murid`.`id_user` AS `id_user`,`tb_murid`.`nisn` AS `nisn`,`tb_murid`.`nama` AS `nama`,`tb_murid`.`foto` AS `foto`,`tb_murid`.`alamat` AS `alamat`,`tb_murid`.`tempat_lahir` AS `tempat_lahir`,`tb_murid`.`tanggal_lahir` AS `tanggal_lahir`,`tb_user`.`username` AS `username`,`tb_user`.`password` AS `password`,`tb_level`.`id` AS `id_level`,`tb_level`.`level` AS `level` from ((`tb_murid` join `tb_user` on((`tb_murid`.`id_user` = `tb_user`.`id`))) join `tb_level` on((`tb_level`.`id` = `tb_user`.`id_level`))) ;

-- --------------------------------------------------------

--
-- Struktur untuk view `v_user`
--
DROP TABLE IF EXISTS `v_user`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_user`  AS  select `u`.`id` AS `user_id`,`u`.`username` AS `username`,`u`.`password` AS `password`,`l`.`level` AS `level` from (`tb_user` `u` join `tb_level` `l` on((`u`.`id_level` = `l`.`id`))) ;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `nohp_walmur`
--
ALTER TABLE `nohp_walmur`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nomor` (`nomor`),
  ADD KEY `fk_nohp_walmur` (`id_walmur`);

--
-- Indeks untuk tabel `tb_bidang_studi`
--
ALTER TABLE `tb_bidang_studi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_guru`
--
ALTER TABLE `tb_guru`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_user` (`id_user`),
  ADD UNIQUE KEY `nip` (`nip`),
  ADD KEY `id_mapel` (`id_mapel`),
  ADD KEY `id_kelas` (`id_kelas`),
  ADD KEY `id_jurusan` (`id_jurusan`);

--
-- Indeks untuk tabel `tb_jurusan`
--
ALTER TABLE `tb_jurusan`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode` (`kode`),
  ADD KEY `fk_jurusan_1` (`id_bidstud`);

--
-- Indeks untuk tabel `tb_kelas`
--
ALTER TABLE `tb_kelas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nama` (`nama`);

--
-- Indeks untuk tabel `tb_level`
--
ALTER TABLE `tb_level`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `level` (`level`);

--
-- Indeks untuk tabel `tb_mapel`
--
ALTER TABLE `tb_mapel`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode` (`kode`);

--
-- Indeks untuk tabel `tb_mapelkelasjurusan`
--
ALTER TABLE `tb_mapelkelasjurusan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_mapelkelasjurusan_1` (`id_jurusan`),
  ADD KEY `fk_mapelkelasjurusan_2` (`id_kelas`),
  ADD KEY `fk_mapelkelasjurusan_3` (`id_mapel`);

--
-- Indeks untuk tabel `tb_murid`
--
ALTER TABLE `tb_murid`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nisn` (`nisn`),
  ADD UNIQUE KEY `id_user` (`id_user`),
  ADD KEY `fk_murid_1` (`id_jurusan`),
  ADD KEY `fk_murid_2` (`id_kelas`);

--
-- Indeks untuk tabel `tb_nilai`
--
ALTER TABLE `tb_nilai`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_nilai_1` (`id_sub_mapel`),
  ADD KEY `fk_nilai_2` (`id_murid`),
  ADD KEY `fk_nilai_3` (`id_guru`);

--
-- Indeks untuk tabel `tb_sub_mapel`
--
ALTER TABLE `tb_sub_mapel`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode` (`kode`),
  ADD KEY `fk_sub_mapel_1` (`id_mapel`);

--
-- Indeks untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `fk_user_1` (`id_level`);

--
-- Indeks untuk tabel `tb_walmur`
--
ALTER TABLE `tb_walmur`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_murid` (`id_murid`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `nohp_walmur`
--
ALTER TABLE `nohp_walmur`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `tb_bidang_studi`
--
ALTER TABLE `tb_bidang_studi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `tb_jurusan`
--
ALTER TABLE `tb_jurusan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tb_kelas`
--
ALTER TABLE `tb_kelas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tb_mapel`
--
ALTER TABLE `tb_mapel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tb_mapelkelasjurusan`
--
ALTER TABLE `tb_mapelkelasjurusan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tb_nilai`
--
ALTER TABLE `tb_nilai`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `tb_sub_mapel`
--
ALTER TABLE `tb_sub_mapel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `nohp_walmur`
--
ALTER TABLE `nohp_walmur`
  ADD CONSTRAINT `fk_nohp_walmur` FOREIGN KEY (`id_walmur`) REFERENCES `tb_walmur` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tb_guru`
--
ALTER TABLE `tb_guru`
  ADD CONSTRAINT `id_jurusan` FOREIGN KEY (`id_jurusan`) REFERENCES `tb_jurusan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `id_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `tb_kelas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `id_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `tb_mapel` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `id_user` FOREIGN KEY (`id_user`) REFERENCES `tb_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tb_jurusan`
--
ALTER TABLE `tb_jurusan`
  ADD CONSTRAINT `fk_jurusan_1` FOREIGN KEY (`id_bidstud`) REFERENCES `tb_bidang_studi` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tb_mapelkelasjurusan`
--
ALTER TABLE `tb_mapelkelasjurusan`
  ADD CONSTRAINT `fk_mapelkelasjurusan_1` FOREIGN KEY (`id_jurusan`) REFERENCES `tb_jurusan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_mapelkelasjurusan_2` FOREIGN KEY (`id_kelas`) REFERENCES `tb_kelas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_mapelkelasjurusan_3` FOREIGN KEY (`id_mapel`) REFERENCES `tb_mapel` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tb_murid`
--
ALTER TABLE `tb_murid`
  ADD CONSTRAINT `fk_murid_1` FOREIGN KEY (`id_jurusan`) REFERENCES `tb_jurusan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_murid_2` FOREIGN KEY (`id_kelas`) REFERENCES `tb_kelas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_murid_3` FOREIGN KEY (`id_user`) REFERENCES `tb_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tb_nilai`
--
ALTER TABLE `tb_nilai`
  ADD CONSTRAINT `fk_nilai_1` FOREIGN KEY (`id_sub_mapel`) REFERENCES `tb_sub_mapel` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_nilai_2` FOREIGN KEY (`id_murid`) REFERENCES `tb_murid` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_nilai_3` FOREIGN KEY (`id_guru`) REFERENCES `tb_guru` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tb_sub_mapel`
--
ALTER TABLE `tb_sub_mapel`
  ADD CONSTRAINT `fk_sub_mapel_1` FOREIGN KEY (`id_mapel`) REFERENCES `tb_mapel` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  ADD CONSTRAINT `fk_user_1` FOREIGN KEY (`id_level`) REFERENCES `tb_level` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tb_walmur`
--
ALTER TABLE `tb_walmur`
  ADD CONSTRAINT `fk_walmur_1` FOREIGN KEY (`id_murid`) REFERENCES `tb_murid` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
