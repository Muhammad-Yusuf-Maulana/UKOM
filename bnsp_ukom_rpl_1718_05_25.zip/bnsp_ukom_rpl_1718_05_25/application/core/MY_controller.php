<?php
defined('BASEPATH') or exit('No direct script access allowed');

class MY_controller extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->session->set_userdata('previous_url', current_url());
    }

    public function signout_redirect()
    {
      $message = "<div class='alert alert-success'>
        Kamu telah berhasil Sign Out
      </div>";
      $this->session->set_flashdata('message', $message);
      redirect(base_url());
    }

}
