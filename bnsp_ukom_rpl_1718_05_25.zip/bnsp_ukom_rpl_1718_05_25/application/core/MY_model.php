<?php
defined('BASEPATH') or exit('No direct script access allowed');

// Kesalah penamaan class karena mengopi contoh sintaks dari MY_controller
// class MY_controller extends CI_Controller
// Berikut sintaks yang sudah diperbaiki
class MY_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->session->set_userdata('previous_url', current_url());
    }

}
