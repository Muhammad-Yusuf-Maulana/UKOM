 <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Guru extends CI_Controller {

    public function index() {

        if($this->session->userdata('login') == TRUE){
            if ($this->input->get('q') != null) {
                // $data['title'] = "Dashboard Guru | APES";
                $data = [
                    'title' => 'Dashboard Guru | APES',
                    'mapel' => $this->M_mapel->get($this->input->get()),
                    'list' => $data['list'] = $this->M_murid->listNilai(),
                    'listnama' => $this->M_guru->getNama(),
                    'listsubmapel' => $this->M_guru->getSubMapel()

                ]; 
                // $np = 'nh_pengetahuan';
                // var_dump($np);
                $this->form_validation->set_rules('id_sub_mapel', 'id_sub_mapel', 'required');
                $this->form_validation->set_rules('id_guru', 'id_guru', 'required');
                $this->form_validation->set_rules('id_murid', 'id_murid', 'required');
                $this->form_validation->set_rules('nilai_pengetahuan', 'nilai_pengetahuan', 'required');
                $this->form_validation->set_rules('nilai_keterampilan', 'nilai_ketrampilan', 'required');
                if('nilai_pengetahuan' == 100){
                    'nh_pengetahuan' == 'A';
                }
                // $this->form_validation->set_rules('nh_pengetahuan', 'nh_pengetahuan', 'required');
                // $this->form_validation->set_rules('nh_keterampilan', 'nh_ketrampilan', 'required');
                $this->form_validation->set_rules('jenis', 'jenis', 'required');
                $this->form_validation->set_rules('tahun_ajaran', 'tahun_ajaran', 'required');

                if( $this->form_validation->run() == FALSE ) {
                    
                    $this->load->view('Templates/header', $data);
                    $this->load->view('Templates/second_navbar', $data);
                    $this->load->view('DashboardGuru/index', $data);
                    $this->load->view('Templates/footer', $data);
        
                } else {
    
                    $this->M_guru->inputNilai();
                    redirect('home');
                }
            } else {
                $data = [
                    'title' => 'Dashboard Guru | APES',
                    'mapel' => $this->M_mapel->get($this->input->get()),
                    'list' => $this->M_murid->listNilai(),
                    'listnama' => $this->M_guru->getNama(),
                    'listsubmapel' => $this->M_guru->getSubMapel()
                ]; 

                $this->form_validation->set_rules('id_sub_mapel', 'id_sub_mapel', 'required');
                $this->form_validation->set_rules('id_guru', 'id_guru', 'required');
                $this->form_validation->set_rules('id_murid', 'id_murid', 'required');
                $this->form_validation->set_rules('nilai_pengetahuan', 'nilai_pengetahuan', 'required');
                $this->form_validation->set_rules('nilai_keterampilan', 'nilai_ketrampilan', 'required');
                // $this->form_validation->set_rules('nh_pengetahuan', 'nh_pengetahuan', 'required');
                // $this->form_validation->set_rules('nh_keterampilan', 'nh_ketrampilan', 'required');
                $this->form_validation->set_rules('jenis', 'jenis', 'required');
                $this->form_validation->set_rules('tahun_ajaran', 'tahun_ajaran', 'required');

                if( $this->form_validation->run() == FALSE ) {
                    
                    $this->load->view('Templates/header', $data);
                    $this->load->view('Templates/second_navbar', $data);
                    $this->load->view('DashboardGuru/index', $data);
                    $this->load->view('Templates/footer', $data);
        
                } else {
    
                    $this->M_guru->inputNilai();
                    redirect('home');
                }
            }
        
        } else {
			redirect(base_url());
		}
    }

    public function hapus($id) {

	  	$this->M_murid->hapusData($id);
		redirect('Guru');

	}
    
}
