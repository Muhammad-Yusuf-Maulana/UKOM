<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jurusan extends MY_controller {

  public function index()
  {
    if ($this->session->userdata('login') == true) {
      if ($this->input->get('q') != null) {
          $data = [
            'title' => 'Administrator Dashboard',
            'jurusan' => $this->M_jurusan->search($this->input->get()),
            'bidstud' => $this->M_bidstud->get()
          ];
          $this->load->view('Templates/header', $data);
          $this->load->view('Templates/second_navbar', $data);
          $this->load->view('Dashboard/Jurusan/index', $data);
          $this->load->view('Dashboard/Jurusan/modal', $data);
          $this->load->view('Templates/footer', $data);
      } else {
        $data = [
          'title' => 'Administrator Dashboard',
          'jurusan' => $this->M_jurusan->get($this->input->get()),
          'bidstud' => $this->M_bidstud->get()
        ];
        $this->load->view('Templates/header', $data);
        $this->load->view('Templates/second_navbar', $data);
        $this->load->view('Dashboard/Jurusan/index', $data);
        $this->load->view('Dashboard/Jurusan/modal', $data);
        $this->load->view('Templates/footer', $data);
      }
    } else {
      redirect(base_url());
    }
  }
  public function hapus($id)
  {
    $this->M_jurusan->delete($id);
  }
  //
  public function ubah($id)
  {
    $this->form_validation->set_rules('kode_jurusan', 'Kode', 'required|trim|max_length[5]', [
      'required' => '* Kode dibutuhkan',
      'max_length' => '* Panjang karakter maksimal 5'
    ]);
    $this->form_validation->set_rules('nama_jurusan', 'Nama', 'required|trim', [
      'required' => '* Nama dibutuhkan'
    ]);
    if ($this->form_validation->run() == false) {
      $this->session->set_flashdata('kode_jurusan', form_error('kode_jurusan'));
      $this->session->set_flashdata('nama_jurusan', form_error('nama_jurusan'));
      redirect(base_url('dashboard/admin/jurusan'));
    } else {
      $data = [
        'id' => $id,
        'kode_jurusan' => $this->input->post('kode_jurusan'),
        'nama_jurusan' => $this->input->post('nama_jurusan')
      ];
      $this->M_jurusan->update($data);
    }
  }

  public function tambah()
  {
    $this->form_validation->set_rules('kode_jurusan', 'Kode', 'required|trim|max_length[5]|is_unique[tb_jurusan.kode]', [
      'required' => '* Kode dibutuhkan',
      'max_length' => '* Panjang karakter maksimal 5',
      'is_unique' => '* Kode sudah terdaftar'
    ]);
    $this->form_validation->set_rules('nama_jurusan', 'Nama', 'required|trim', [
      'required' => '* Nama dibutuhkan'
    ]);
    $this->form_validation->set_rules('bidang_studi', 'Bidang Studi', 'required|trim|numeric');
    if ($this->form_validation->run() == false) {
      $this->session->set_flashdata('kode_jurusan', form_error('kode_jurusan'));
      $this->session->set_flashdata('nama_jurusan', form_error('nama_jurusan'));
      $this->session->set_flashdata('bidang_studi', form_error('bidang_studi'));
      redirect(base_url('dashboard/admin/jurusan'));
    } else {
      $data = [
        'kode_jurusan' => $this->input->post('kode_jurusan'),
        'nama_jurusan' => $this->input->post('nama_jurusan'),
        'bidang_studi' => $this->input->post('bidang_studi')
      ];
      $this->M_jurusan->add($data);
    }
  }

}
