<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_controller {

	public function administrator()
	{
		if ($this->session->userdata('login') == true) {
			// Error tidak terdefinisi variable $data
			// echo "this is admin";
			// Mendefinisikan variabel data
			$data['title'] = 'Administrator Dashboard';
			$this->load->view('Templates/header', $data);
			$this->load->view('Templates/second_navbar', $data);
			$this->load->view('Dashboard/admin/index', $data); 
			$this->load->view('Templates/footer', $data);
		} else {
			redirect(base_url());
		}
	}

	public function signout()
	{
		$this->session->unset_userdata('username');
		$this->session->unset_userdata('role');
		$this->session->set_userdata('login', false);
		$this->signout_redirect();
	}

	// public function guru()
	// {
    //     $data['judul'] = "Dashboard | APES";
	// 	$this->load->view('DashboardGuru/index', $data);

	// }
	// public function murid()
	// {
    //     $data['judul'] = "Dashboard | APES";

	// 	$this->load->view('DashboardMurid/index', $data);
	// }
}
