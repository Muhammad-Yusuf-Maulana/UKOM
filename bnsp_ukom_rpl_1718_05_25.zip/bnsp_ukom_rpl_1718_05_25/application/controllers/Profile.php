<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {

	
	public function admin()
	{
        if($this->session->userdata('login') == TRUE){
            $data['title'] = "Profile Admin | APES" ;

            $this->load->view('Templates/header', $data);
            $this->load->view('Templates/second_navbar', $data);
            $this->load->view('Profile/index', $data); 
            $this->load->view('Templates/footer', $data);
        } else {
			redirect(base_url());
		}
    }
    
    public function guru()
	{
        if($this->session->userdata('login') == TRUE){
            $data = [
                
                'title' => 'Profile Guru | APES',
                'listsubmapel' => $this->M_guru->getSubmapel(),
                'namamapel' => $this->M_guru->getMapel()
                // Mapel()
            ]; 
 
            $this->load->view('Templates/header', $data);
            $this->load->view('Templates/second_navbar', $data);
            $this->load->view('Profile/index', $data);
            $this->load->view('Templates/footer', $data);
        } else {
			redirect(base_url());
		}
    }
    
    public function editguru()
	{
        if($this->session->userdata('login') == TRUE){
            $data['title'] = "Edit Profile Guru | APES" ;
 
            $this->form_validation->set_rules('id','id','required');

            if( $this->form_validation->run() == FALSE){

                $this->load->view('Templates/header', $data);
                $this->load->view('Templates/second_navbar', $data);
                $this->load->view('Profile/edit', $data); 
                $this->load->view('Templates/footer', $data);   

            } else{
                $this->M_profile->editGuru();
                redirect('dashboard/signout');
                // $this->session->unset_userdata('username');
                // $this->session->unset_userdata('role');
                // $this->session->set_userdata('login', false);
                // $this->signout_redirect();
            }
        } else {
            redirect(base_url());
		}
    }

    public function signout()
	{
		$this->session->unset_userdata('username');
		$this->session->unset_userdata('role');
		$this->session->set_userdata('login', false);
		$this->signout_redirect();
	}
}
