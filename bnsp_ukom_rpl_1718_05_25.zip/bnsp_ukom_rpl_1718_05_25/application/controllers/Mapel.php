<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mapel extends MY_controller {

  public function index()
  {
    if ($this->session->userdata('login') == true) {
      if ($this->input->get('q') != null) {
          $data = [
            'title' => 'Administrator Dashboard',
            'mapel' => $this->M_mapel->search($this->input->get())
          ]; 
          $this->load->view('Templates/header', $data);
          $this->load->view('Templates/second_navbar', $data);
          $this->load->view('Dashboard/Mapel/index', $data);
          $this->load->view('Dashboard/Mapel/modal', $data);
          $this->load->view('Templates/footer', $data);
      } else {
        $data = [
          'title' => 'Administrator Dashboard',
          'mapel' => $this->M_mapel->get($this->input->get())
        ];
        $this->load->view('Templates/header', $data);
        $this->load->view('Templates/second_navbar', $data);
        $this->load->view('Dashboard/Mapel/index', $data);
        $this->load->view('Dashboard/Mapel/modal', $data);
        $this->load->view('Templates/footer', $data);
      }
    } else {
      redirect(base_url());
    }
  }
  public function hapus($id)
  {
    $this->M_mapel->delete($id);
  }

  public function ubah($id)
  {
    $this->form_validation->set_rules('kode_mapel', 'Kode', 'required|trim|max_length[5]', [
      'required' => '* Kode dibutuhkan',
      'max_length' => '* Panjang karakter maksimal 5'
    ]);
    $this->form_validation->set_rules('nama_mapel', 'Nama', 'required|trim', [
      'required' => '* Nama dibutuhkan'
    ]);
    if ($this->form_validation->run() == false) {
      $this->session->set_flashdata('kode_mapel', form_error('kode_mapel'));
      $this->session->set_flashdata('nama_mapel', form_error('nama_mapel'));
      redirect(base_url('dashboard/admin/mapel'));
    } else {
      $data = [
        'id' => $id,
        'kode_mapel' => $this->input->post('kode_mapel'),
        'nama_mapel' => $this->input->post('nama_mapel')
      ];
      $this->M_mapel->update($data);
    }
  }

  public function tambah()
  {
    $this->form_validation->set_rules('kode_mapel', 'Kode', 'required|trim|max_length[5]|is_unique[tb_mapel.kode]', [
      'required' => '* Kode dibutuhkan',
      'max_length' => '* Panjang karakter maksimal 5',
      'is_unique' => '* Kode sudah terdaftar'
    ]);
    $this->form_validation->set_rules('nama_mapel', 'Nama', 'required|trim', [
      'required' => '* Nama dibutuhkan'
    ]);
    if ($this->form_validation->run() == false) {
      $this->session->set_flashdata('kode_mapel', form_error('kode_mapel'));
      $this->session->set_flashdata('nama_mapel', form_error('nama_mapel'));
      redirect(base_url('dashboard/admin/mapel'));
    } else {
      $data = [
        'kode_mapel' => $this->input->post('kode_mapel'),
        'nama_mapel' => $this->input->post('nama_mapel')
      ];
      $this->M_mapel->add($data);
    }
  }

}
