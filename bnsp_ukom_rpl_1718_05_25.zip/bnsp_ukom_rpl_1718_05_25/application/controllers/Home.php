<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends MY_controller {

	public function index()
	{
		if ($this->session->userdata('username') == true) {
			redirect(base_url('dashboard/admin'));
		} else {
			$this->form_validation->set_rules('username', 'Username', 'required|trim', [
			'required' => '* Silahkan masukkan Username atau NISN kamu'
			]);
			$this->form_validation->set_rules('password', 'Password', 'required|trim', [ 
			'required' => '* Silahkan masukkan Password kamu'
			]);

			if ($this->form_validation->run() == false ) {
				$data['judul'] = "Page Login | APES";
				$this->load->view('Homepage/index', $data);
			} else {
				$username = $this->input->post('username'); 
				$password = $this->input->post('password');
				$admin = $this->M_home->getAdminByUsername($username);
				$guru = $this->M_home->getGuruByUsername($username); 
				$murid = $this->M_home->getMuridByUsername($username);
				if ($admin['password'] === $password) {
					if ($admin['level'] === 'Administrator') {
						$this->session->set_userdata('username', $admin['password']);
						$this->session->set_userdata('role', $admin['level']);
						$this->session->set_userdata('login', true);
						redirect(base_url('dashboard/admin'));
					} elseif ($guru['level'] === 'Guru') {
						$this->session->set_userdata('login', true);
						$this->session->set_userdata('username', $guru['password']); 
						$this->session->set_userdata('role', $guru['level']);
						$this->session->set_userdata('id', $guru['id']);
						$this->session->set_userdata('id_user', $guru['id_user']);
						$this->session->set_userdata('id_mapel', $guru['id_mapel']);
						$this->session->set_userdata('id_kelas', $guru['id_kelas']);
						$this->session->set_userdata('id_jurusan', $guru['id_jurusan']);
						$this->session->set_userdata('foto', $guru['foto']); 
						$this->session->set_userdata('nama', $guru['nama']);
						$this->session->set_userdata('nip', $guru['nip']);
						$this->session->set_userdata('alamat', $guru['alamat']);
						redirect(base_url('guru'));
						
					} elseif ($murid['level'] === 'Murid') {
						$this->session->set_userdata('login', true);
						$this->session->set_userdata('username', $murid['password']);
						$this->session->set_userdata('role', $murid['level']);
						$this->session->set_userdata('nama', $murid['nama']);
						$this->session->set_userdata('nisn', $murid['nisn']);
						$this->session->set_userdata('tempat_lahir', $murid['tempat_lahir']);
						$this->session->set_userdata('tanggal_lahir', $murid['tanggal_lahir']);
						$this->session->set_userdata('alamat', $murid['alamat']);
						redirect(base_url('murid'));
					}
				} else {
					redirect(base_url());
				}
			}
		}
	}
}
