<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Murid extends CI_Controller {

	public function index()
	{
        if($this->session->userdata('login') == TRUE){
            $data['title'] = "Dashboard Murid | APES";

            $this->load->view('Templates/header', $data);
            $this->load->view('Templates/second_navbar', $data);
            $this->load->view('Profile/index', $data);
            $this->load->view('Templates/footer', $data);
        } else {
			redirect(base_url());
		}
	}
}
