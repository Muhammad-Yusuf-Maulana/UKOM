<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- MY CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/css/style.css">
    <title><?= $judul; ?></title>
    <link rel="stylesheet" href="<?= base_url(); ?>assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vendor/fontawesome-free-5.12.0-web/all.min.css">
</head>
<body>
    <div id="main">
        <div class="d-flex justify-content-center align-items-center lapisan-warna">
            <!-- <div class="container bg-dark" style="min-height: 100vh;">
                <div class="test bg-success">
                    test
                </div>
                <div class="test bg-success">
                    test
                </div>
                <div class="test bg-success">
                    test
                </div>
                <div class="test bg-success"> 
                    test
                </div>
            </div> -->
            <!-- <center> -->
                <div class="container bg-white pt-5 pb-5 pl-4 pr-4 rounded" style="width:auto;">
                    <form action="" method="post" class="bg-white p-0" style="min-width:35vw;">
                        <h2 class="apes-color-primary text-center mb-4"><b>SIGN IN</b></h2>
                        <div class="px-2">
                          <?= $this->session->flashdata('message') ?>
                          <div class="my-2">
                            <input type="text" class="form-control" placeholder="USERNAME..." name="username">
                            <!-- Salah Pemanggilan Fungsi form_error -->
                            <!-- $form_error('username') -->
                            <!-- Pemanggilan Fungsi form_error yg benar -->
                            <?= form_error('username', '<small class="text-danger">', '</small>') ?>
                          </div>
                          <div class="my-2">
                            <input type="password" class="form-control" placeholder="PASSWORD..." name="password">
                            <?= form_error('password', '<small class="text-danger">', '</small>') ?>
                          </div>
                            <button class="btn btn-primary float-right mt-3" type="submit">SUBMIT</button>
                        </div>
                    </form>
                </div>
            <!-- </center> -->
        </div>
    </div>


<!--
    <a href="#modal" data-toggle="#modal" data-target="#modal" class="btn btn-primary"> test</a>
        <button type="button" data-toggle="#modal" data-target="#modal" class="btn btn-primary">SUBMIT</button> -->
    <!-- <div id="modal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                testtt
                </div>
            </div>
        </div>
    </div> -->

    <!-- <script src="<?= base_url('')?>assets/bs/js/bootstrap.bundle.min.js"></script>
    <script src="<?= base_url('')?>assets/bs/js/bootstrap.js"></script>
    <script src="<?= base_url('')?>assets/bs/js/bootstrap.min.js"></script>
    <script src="<?= base_url('')?>assets/bs/js/jquery-3.4.1.slim.min.js"></script>
    <script src="<?= base_url('')?>assets/bs/js/jquery.min.js"></script>
    <script src="<?= base_url('')?>assets/bs/js/jquery2.min.js"></script>
    <script src="<?= base_url('')?>assets/bs/js/js.bootstrap.min.js"></script>
    <script src="<?= base_url('')?>assets/bs/js/popper.min.js"></script> -->
</body>
</html>
