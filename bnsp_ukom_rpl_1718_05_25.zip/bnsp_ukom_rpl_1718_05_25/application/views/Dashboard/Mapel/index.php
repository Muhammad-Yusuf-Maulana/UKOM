<div class="container p-5">

  <?= $this->session->flashdata('message') ?>

  <form class="container" action="" method="get">
    <div class="row align-items-end">
      <div class="form-group">
        <label for="nama" class="form-label form-label-sm">Nama</label>
        <input type="text" name="q" class="form-control form-control-sm" value="<?= set_value('q') ?>">
      </div>
    </div>
    <div class="row align-items-end">
      <div class="form-group">
        <label class="form-label form-label-sm">Sort By :</label>
        <div class="d-flex">
          <select class="custom-select form-control-sm mr-1" name="field">
            <option>-</option>
            <option value="kode">Kode</option>
            <option value="nama">Nama</option>
          </select>
          <select class="custom-select form-control-sm mx-1" name="sortby">
            <option>-</option>
            <option value="ASC">ASC</option> 
            <option value="DESC">DESC</option>
          </select>
        </div>
      </div>
      <div class="ml-auto form-group">
        <button type="submit" class="btn btn-primary btn-sm">Submit</button>
      </div>
    </div>
  </form>

  <div class="table-responsive">
    <table class="table table-striped table-borderless table-hover">
      <thead class="apes-thead">
          <td>No.</td>
          <td>Kode</td>
          <td>Nama</td>
          <td>Aksi</td>
      </thead>
      <tbody class="text-center">
        <?php $no=1; foreach ($mapel as $data) : ?>
          <tr>
            <td><?= $no++ ?></td>
            <td><?= $data['kode'] ?></td>
            <td><?= $data['nama'] ?></td>
            <td>
              <button type="button" class="btn btn-info" data-toggle="modal" data-target="#ubahModal<?=$data['id']?>">Ubah</button>
              <a href="<?= base_url('dashboard/admin/mapel/hapus/'.$data['id']) ?>" class="btn btn-danger">Hapus</a>
            </td>
          </tr>

          <div class="modal fade" id="ubahModal<?= $data['id'] ?>" role="dialog">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title text-apes-primary">Ubah Mata Pelajaran</h5>
                  <button type="button" class="close" data-dismiss="modal">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
                <form class="" action="<?= base_url('dashboard/admin/mapel/ubah/'.$data['id']) ?>" method="post">
                  <div class="container">
                    <div class="modal-body">
                      <div class="row">
                        <div class="col-12 form-group">
                          <label for="kode_mapel" class="form-label">Kode</label>
                          <input id="kode_mapel" type="text" class="form-control" name="kode_mapel" value="<?= $data['kode'] ?>">
                          <small class="text-danger"><?= $this->session->flashdata('kode_mapel') ?></small>
                        </div>
                        <div class="col-12 form-group">
                          <label for="nama_mapel" class="form-label">Nama Mata Pelajaran</label>
                          <input id="nama_mapel" type="text" class="form-control" name="nama_mapel" value="<?= $data['nama'] ?>">
                          <small class="text-danger"><?= $this->session->flashdata('nama_mapel') ?></small>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="submit" class="btn-sm btn-apes-primary rounded">Submit</button>
                  </div>
                </form>
              </div>
            </div>

        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <button type="button" class="btn-apes-primary btn-sm" data-toggle="modal" data-target="#addModal">
    <i class="fas fa-plus"></i>
    Tambah Data</button>
