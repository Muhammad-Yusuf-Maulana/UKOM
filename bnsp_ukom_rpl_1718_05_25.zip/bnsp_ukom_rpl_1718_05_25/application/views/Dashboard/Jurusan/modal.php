<div class="modal fade" id="addModal" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-apes-primary">Tambah Jurusan</h5>
        <button type="button" class="close" data-dismiss="modal">
          <i class="fas fa-times"></i>
        </button>
      </div>
      <form class="" action="<?= base_url('dashboard/admin/jurusan/tambah') ?>" method="post">
        <div class="container">
          <div class="modal-body">
            <div class="row">
              <div class="col-12 form-group">
                <label for="kode_jurusan" class="form-label">Kode</label>
                <input id="kode_jurusan" type="text" class="form-control" name="kode_jurusan">
                <small class="text-danger"><?= $this->session->flashdata('kode_jurusan') ?></small>
              </div>
              <div class="col-12 form-group">
                <label for="nama_jurusan" class="form-label">Nama Jurusan</label>
                <input id="nama_jurusan" type="text" class="form-control" name="nama_jurusan">
                <small class="text-danger"><?= $this->session->flashdata('nama_jurusan') ?></small>
              </div>
              <div class="col-12 form-group">
                <label for="bidang_studi" class="form-label">Bidang Studi</label>
                <select class="custom-select" name="bidang_studi" id="bidang_studi">
                  <?php foreach ($bidstud as $data): ?>
                    <option value="<?= $data['id'] ?>"><?= $data['name'] ?></option>
                  <?php endforeach; ?>
                </select>
                <small class="text-danger"><?= $this->session->flashdata('bidang_studi') ?></small>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn-sm btn-apes-primary rounded">Submit</button>
        </div>
      </form>
    </div>
  </div>

</div>
