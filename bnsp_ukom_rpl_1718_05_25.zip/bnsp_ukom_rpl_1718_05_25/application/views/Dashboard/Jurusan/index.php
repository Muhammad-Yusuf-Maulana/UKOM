<div class="container p-5">

  <?= $this->session->flashdata('message') ?>

  <form class="container" action="" method="get">
    <div class="row align-items-end">
      <div class="form-group mr-1">
        <label for="nama" class="form-label form-label-sm">Nama</label>
        <input type="text" name="q" class="form-control form-control-sm" value="<?= set_value('q') ?>">
      </div>
      <div class="form-group mx-1">
        <label for="bidstud" class="form-label form-label-sm">Bidang Studi</label>
        <select class="custom-select custom-select-sm" name="qbid">
          <option>-</option>
          <?php foreach ($bidstud as $data): ?>
            <option value="<?= $data['name'] ?>"><?= $data['name'] ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>
    <div class="row align-items-end">
      <div class="form-group">
        <label class="form-label form-label-sm">Sort By :</label>
        <div class="d-flex">
          <select class="custom-select custom-select-sm mr-1" name="field">
            <option>-</option>
            <option value="kode">Kode</option>
            <option value="nama">Nama</option>
            <option value="bidang_studi">Bidang Studi</option>
          </select>
          <select class="custom-select custom-select-sm mx-1" name="sortby">
            <option>-</option>
            <option value="ASC">ASC</option>
            <option value="DESC">DESC</option>
          </select>
        </div>
      </div>
      <div class="ml-auto form-group">
        <button type="submit" class="btn btn-primary btn-sm">Submit</button>
      </div>
    </div>
  </form>

  <div class="table-responsive">
    <table class="table table-striped table-borderless table-hover">
      <thead class="apes-thead">
          <td>No.</td>
          <td>Kode</td>
          <td>Nama</td>
          <td>Bidang Studi</td>
          <td>Aksi</td>
      </thead>
      <tbody class="text-center">
        <?php $no=1; foreach ($jurusan as $data) : ?>
          <tr>
            <td><?= $no++ ?></td>
            <td><?= $data['kode'] ?></td>
            <td><?= $data['nama'] ?></td>
            <td><?= $data['bidang_studi'] ?></td>
            <td>
              <button type="button" class="btn btn-info" data-toggle="modal" data-target="#ubahModal<?=$data['id_jurusan']?>">Ubah</button>
              <a href="<?= base_url('dashboard/admin/jurusan/hapus/'.$data['id_jurusan']) ?>" class="btn btn-danger">Hapus</a>
            </td>
          </tr>

          <div class="modal fade" id="ubahModal<?= $data['id_jurusan'] ?>" role="dialog">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title text-apes-primary">Ubah Jurusan</h5>
                  <button type="button" class="close" data-dismiss="modal">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
                <form class="" action="<?= base_url('dashboard/admin/jurusan/ubah/'.$data['id_jurusan']) ?>" method="post">
                  <div class="container">
                    <div class="modal-body">
                      <div class="row">
                        <div class="col-12 form-group">
                          <label for="kode_jurusan" class="form-label">Kode</label>
                          <input id="kode_jurusan" type="text" class="form-control" name="kode_jurusan" value="<?= $data['kode'] ?>">
                          <small class="text-danger"><?= $this->session->flashdata('kode_jurusan') ?></small>
                        </div>
                        <div class="col-12 form-group">
                          <label for="nama_jurusan" class="form-label">Nama Mata Pelajaran</label>
                          <input id="nama_jurusan" type="text" class="form-control" name="nama_jurusan" value="<?= $data['nama'] ?>">
                          <small class="text-danger"><?= $this->session->flashdata('nama_jurusan') ?></small>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="submit" class="btn-sm btn-apes-primary rounded">Submit</button>
                  </div>
                </form>
              </div>
            </div>

        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <button type="button" class="btn-apes-primary btn-sm" data-toggle="modal" data-target="#addModal">
    <i class="fas fa-plus"></i>
    Tambah Data</button>
