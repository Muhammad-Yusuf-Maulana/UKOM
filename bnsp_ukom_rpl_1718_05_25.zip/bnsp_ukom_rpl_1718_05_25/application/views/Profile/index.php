<?php if( $this->session->userdata('role')== 'Administrator' ) : ?>
    <div class="container pt-5 mt-5" style="min-height: 700px;">
        <div class="row">
            <div class="col-md-12" style="min-height: 300px;">
                <div class="d-flex justify-content-center " style="height: 70%;">
                    <img src="<?= base_url(); ?>assets/img/icon/user.png" alt="pict" style="width: 200px;">
                </div>
                <div class="d-flex justify-content-center align-items-center" style="height: 30%;">
                    <center> 
                        <!-- <a href="#" class="btn btn-primary" style="width: 200px;">Edit Profile</a> -->
                        <a href="<?= base_url(); ?>profile/editadmin" class="btn btn-success" style="width: 200px;">Edit Profile</a>
                    </center>    
                </div>
            </div>
            <div class="col-md-12" style="min-height: 300px;">
                <div class="table-responsive apes-bg-seccondary p-3" style="height: 70%; border-radius: 8px 8px 0px 0px">
                    <table>
                        <tr>
                            <td>
                                                            <label for="nama" class="form-label form-label-sm">Nama</label>
                            </td>
                            <td>:</td> 
                            <td>
                                                    <input type="text" name="tahun_ajaran" class="form-control form-control-sm" value="<?= base_url(). $this->session->userdata('nama');?>">
                            </td>
                        </tr>
                        <tr>
                            <td>NISN</td>
                            <td>:</td> 
                            <td>6</td>
                        </tr>
                        <tr>
                            <td>Tempat, TGL Lahir</td>
                            <td>:</td>
                            <td>6</td>
                        </tr>
                        <tr>
                            <td>Alamat</td>
                            <td>:</td>
                            <td>6</td>
                        </tr>
                    </table> 
                </div>
                <div class="d-flex align-items-center justify-content-center apes-bg-primary" style="height: 30%; border-radius: 0px 0px 8px 8px">
                        <b class="text-center font-weight-bold text-white">MY PROFILE</b>
                </div>
            </div>
        </div>
    </div>
<?php elseif( $this->session->userdata('role')== 'Guru' ) : ?>
    <div class="container pt-5 mt-5 rounded" style="">
        <div class="row">
            <div class="col-md-12" style="min-height: 300px;">
                <div class="d-flex justify-content-center " style="height: 70%;">
                    <img src="<?= base_url(). $this->session->userdata('foto');?>" alt="pict" style="width: 200px;">
                </div>
                <div class="d-flex justify-content-center align-items-center" style="height: 30%;">
                    <center> 
                        <!-- <a href="#" class="btn btn-primary" style="width: 200px;">Edit Profile</a> -->
                        <a href="<?= base_url(); ?>profile/editguru" class="btn btn-success" style="width: 200px;">Edit Profile</a>
                    </center>    
                </div>
            </div>
            <div class="col-md-12" style="min-height: 300px;">
                <div class="table-responsive apes-bg-seccondary p-3" style=" border-radius: 8px 8px 0px 0px">
                    <table class="col-md-12">
                        <tr>
                            <td>
                                <label for="nama" class="mt-3 form-label form-label-sm">Nama</label>
                            </td>
                            <td>:</td> 
                            <td>
                                <input type="text" name="nama" class="form-control form-control-sm" value="<?= $this->session->userdata('nama');?>" disabled/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label for="nama" class="mt-3 form-label form-label-sm">Nip</label>
                            </td>
                            <td>:</td> 
                            <td>
                                <input type="text" name="nama" class="form-control form-control-sm" value="<?= $this->session->userdata('nip');?>" disabled/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label for="nama" class="mt-3 form-label form-label-sm">Alamat</label>
                            </td>
                            <td>:</td> 
                            <td>
                                <input type="text" name="nama" class="form-control" value="<?= $this->session->userdata('alamat');?>" disabled/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label for="nama" class="mt-3 form-label form-label-sm">Mapel Yang Diajarkan</label>
                            </td>
                            <td>:</td> 
                            <td>
                        <?php foreach($namamapel as $nm) :?> 
                                <input type="text" name="nama" class="form-control" value="<?= $nm['kode'];?>" disabled/>
                        <?php endforeach; ?>
                            </td>
                        </tr>
                        <?php $no = 1 ?>
                        <?php foreach($listsubmapel as $lsm) :?> 
                        <tr>
                            <td>
                                <label for="nama" class="mt-3 form-label form-label-sm">Sub Mapel <?= $no; ?></label>
                            </td>
                            <td>:</td>
                            <td>
                                <input type="text" name="nama" class="form-control" value="<?= $lsm['nama'];?>" disabled/>
                            </td>
                        </tr>
                        <?php $no++; ?>
                        <?php endforeach; ?>
                    </table>
                </div>
                <div class="d-flex align-items-center justify-content-center apes-bg-primary mb-5" style="height: 30%; border-radius: 0px 0px 8px 8px">
                        <b class="text-center font-weight-bold text-white">MY PROFILE</b>
                </div>
            </div>
        </div>
    </div>
<?php elseif( $this->session->userdata('role')== 'Murid' ) : ?>
    <div class="container pt-5 mt-5" style="min-height: 700px;">
        <div class="row">
            <div class="col-md-6" style="min-height: 300px;">
                <div class="d-flex justify-content-center " style="height: 70%;">
                    <img src="<?= base_url(); ?>assets/img/icon/user.png" alt="pict" style="width: 200px;">
                </div>
                <div class="d-flex justify-content-center align-items-center" style="height: 30%;">
                    <center> 
                        <!-- <a href="#" class="btn btn-primary" style="width: 200px;">Edit Profile</a> -->
                        <a href="<?= base_url(); ?>profile/editmurid" class="btn btn-success" style="width: 200px;">Edit Profile</a>
                    </center>    
                </div>
            </div>
            <div class="col-md-6" style="min-height: 300px;">
                <div class="table-responsive apes-bg-seccondary p-3" style="height: 70%; border-radius: 8px 8px 0px 0px">
                    <table>
                        <tr>
                            <td>Nama</td>
                            <td>:</td> 
                            <td><?= $this->session->userdata('nama');?></td>
                        </tr>
                        <tr>
                            <td>NISN</td>
                            <td>:</td>
                            <td><?= $this->session->userdata('nisn');?></td>
                        </tr>
                        <tr>
                            <td>Tempat, TGL Lahir</td>
                            <td>:</td>
                            <td><?= $this->session->userdata('tempat_lahir');?></td>
                            <td><?= $this->session->userdata('tanggal_lahir');?></td>
                        </tr>
                        <tr>
                            <td>Alamat</td>
                            <td>:</td>
                            <td><?= $this->session->userdata('alamat');?></td>
                        </tr>
                    </table>
                </div>
                <div class="d-flex align-items-center justify-content-center apes-bg-primary" style="height: 30%; border-radius: 0px 0px 8px 8px">
                        <b class="text-center font-weight-bold text-white">MY PROFILE</b>
                </div>
            </div>
        </div>

        <div class="table-responsive mt-5">
            <table class="table table-striped table-borderless table-hover">
                <thead class="apes-thead">
                    <td>No.</td>
                    <td>Mata Pelajaran</td>
                    <td>Pengetahuan</td>
                    <td>Keterampilan</td>
                    <td>Nilai Akhir</td>
                    <td>Predikat</td>
                </thead>
                <tbody class="text-center">
                <tr>
                    <td>1.</td>
                    <td>Matematika</td>
                    <td>70</td>
                    <td>70</td>
                    <td>70</td>
                    <td>C</td>
                </tr>
                </tbody>
            </table>
        </div> 

    </div>
<?php endif;?>   

    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        } );
    </script>

    <script src="<?= base_url(); ?>assets/js/btn.delete.sweetalert.js"></script>
    <script src="<?= base_url(); ?>assets/js/sweetalert2.all.min.js"></script>
</body>
</html>

