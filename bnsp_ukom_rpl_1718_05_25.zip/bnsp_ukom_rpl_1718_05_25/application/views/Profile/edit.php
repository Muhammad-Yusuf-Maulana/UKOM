<?php if( $this->session->userdata('role')== 'Administrator' ) : ?>
    <div class="container pt-5 mt-5" style="min-height: 700px;">
        <div class="row">
            <div class="col-md-12" style="min-height: 300px;">
                <div class="d-flex justify-content-center " style="height: 70%;">
                    <img src="<?= base_url(); ?>assets/img/icon/user.png" alt="pict" style="width: 200px;">
                </div>
                <div class="d-flex justify-content-center align-items-center" style="height: 30%;">
                    <center> 
                        <!-- <a href="#" class="btn btn-primary" style="width: 200px;">Edit Profile</a> -->
                        <button type="button" class="btn btn-success" style="width: 200px;">Edit Profile</button>
                    </center>    
                </div>
            </div>
            <div class="col-md-12" style="min-height: 300px;">
                <div class="table-responsive apes-bg-seccondary p-3" style="height: 70%; border-radius: 8px 8px 0px 0px">
                    <table>
                        <tr>
                            <td>Nama</td>
                            <td>:</td> 
                            <td><?= base_url(). $this->session->userdata('nama');?></td>
                        </tr>
                        <tr>
                            <td>NISN</td>
                            <td>:</td>
                            <td>6</td>
                        </tr>
                        <tr>
                            <td>Tempat, TGL Lahir</td>
                            <td>:</td>
                            <td>6</td>
                        </tr>
                        <tr>
                            <td>Alamat</td>
                            <td>:</td>
                            <td>6</td>
                        </tr>
                    </table> 
                </div>
                <div class="d-flex align-items-center justify-content-center apes-bg-primary" style="height: 30%; border-radius: 0px 0px 8px 8px">
                        <b class="text-center font-weight-bold text-white">MY PROFILE</b>
                </div>
            </div>
        </div>
    </div>
<?php elseif( $this->session->userdata('role')== 'Guru' ) : ?>
    <div class="container pt-5 mt-5 pb-5 rounded" style="background-color: #e9e9e9; min-height: 700px;">
        <form action="<?= base_url(); ?>profile/editguru" method="post" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-12" style="min-height: 300px;">
                    <div class="d-flex justify-content-center " style="height: 70%;">
                        <img src="<?= base_url(). $this->session->userdata('foto');?>" alt="pict" style="width: 200px;">
                    </div>
                    <div class="d-flex justify-content-center align-items-center ">
                        <div class="custom-file mt-4 col-md-3">
                            <input type="file" name="foto" class="custom-file-input font-default" id="validatedCustomFile">
                            <label class="custom-file-label" for="validatedCustomFile">Pilih Foto</label>
                        </div>
                    </div>
                </div>
                <div class="col-md-12" style="min-height: 350px;">
                    <div class="table-responsive apes-bg-seccondary p-3" style=" border-radius: 8px 8px 0px 0px">
                        <table class="col-md-12">
                            <tr>
                                <td>
                                    <label for="nama" class="mt-3 form-label form-label-sm">Nama</label>
                                </td>
                                <td>:</td>  
                                <td>
                                    <input type="text" name="id" class="form-control form-control-sm" value="<?= $this->session->userdata('id');?>">
                                    <input type="text" name="id_mapel" class="form-control form-control-sm" value="<?= $this->session->userdata('id_mapel');?>">
                                    <input type="text" name="id_kelas" class="form-control form-control-sm" value="<?= $this->session->userdata('id_kelas');?>">
                                    <input type="text" name="id_jurusan" class="form-control form-control-sm" value="<?= $this->session->userdata('id_jurusan');?>">
                                    <input type="text" name="id_user" class="form-control form-control-sm" value="<?= $this->session->userdata('id_user');?>">
                                    <input type="text" name="nama" class="form-control form-control-sm" value="<?= $this->session->userdata('nama');?>">
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label for="nama" class="mt-3 form-label form-label-sm">Nip</label>
                                </td>
                                <td>:</td> 
                                <td>
                                    <input type="text" name="nip" class="form-control form-control-sm" value="<?= $this->session->userdata('nip');?>">
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label for="nama" class="mt-3 form-label form-label-sm">Alamat</label>
                                </td>
                                <td>:</td> 
                                <td>
                                    <input type="text" name="alamat" class="form-control" value="<?= $this->session->userdata('alamat');?>">
                                </td>
                            </tr>
                        </table>
                        <div class="row justify-content-between col-md-12 mt-5">
                            <a href="<?= base_url(); ?>profile/guru" class="btn btn-danger">Batal</a>
                            <button type="submit" class="btn btn-success">Simpan</button>
                            <!-- <button type="submit" class="btn btn-primary">Save Menu</button> -->
                        </div>
                    </div>
                    <div class="d-flex align-items-center justify-content-center apes-bg-primary" style="height: 80px; border-radius: 0px 0px 8px 8px">
                            <b class="text-center font-weight-bold text-white">MY PROFILE</b>
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php elseif( $this->session->userdata('role')== 'Murid' ) : ?>
    <div class="container pt-5 mt-5" style="min-height: 700px;">
        <div class="row">
            <div class="col-md-6" style="min-height: 300px;">
                <div class="d-flex justify-content-center " style="height: 70%;">
                    <img src="<?= base_url(); ?>assets/img/icon/user.png" alt="pict" style="width: 200px;">
                </div>
                <div class="d-flex justify-content-center align-items-center" style="height: 30%;">
                    <center> 
                        <!-- <a href="#" class="btn btn-primary" style="width: 200px;">Edit Profile</a> -->
                        <button type="button" class="btn btn-success" style="width: 200px;">Edit Profile</button>
                    </center>    
                </div>
            </div>
            <div class="col-md-6" style="min-height: 300px;">
                <div class="table-responsive apes-bg-seccondary p-3" style="height: 70%; border-radius: 8px 8px 0px 0px">
                    <table>
                        <tr>
                            <td>Nama</td>
                            <td>:</td> 
                            <td><?= $this->session->userdata('nama');?></td>
                        </tr>
                        <tr>
                            <td>NISN</td>
                            <td>:</td>
                            <td><?= $this->session->userdata('nisn');?></td>
                        </tr>
                        <tr>
                            <td>Tempat, TGL Lahir</td>
                            <td>:</td>
                            <td><?= $this->session->userdata('tempat_lahir');?></td>
                            <td><?= $this->session->userdata('tanggal_lahir');?></td>
                        </tr>
                        <tr>
                            <td>Alamat</td>
                            <td>:</td>
                            <td><?= $this->session->userdata('alamat');?></td>
                        </tr>
                    </table>
                </div>
                <div class="d-flex align-items-center justify-content-center apes-bg-primary" style="height: 30%; border-radius: 0px 0px 8px 8px">
                        <b class="text-center font-weight-bold text-white">MY PROFILE</b>
                </div>
            </div>
        </div>

        <div class="table-responsive mt-5">
            <table class="table table-striped table-borderless table-hover">
                <thead class="apes-thead">
                    <td>No.</td>
                    <td>Mata Pelajaran</td>
                    <td>Pengetahuan</td>
                    <td>Keterampilan</td>
                    <td>Nilai Akhir</td>
                    <td>Predikat</td>
                </thead>
                <tbody class="text-center">
                <tr>
                    <td>1.</td>
                    <td>Matematika</td>
                    <td>70</td>
                    <td>70</td>
                    <td>70</td>
                    <td>C</td>
                </tr>
                </tbody>
            </table>
        </div> 

    </div>
<?php endif;?>   

    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        } );
    </script>

    <script src="<?= base_url(); ?>assets/js/btn.delete.sweetalert.js"></script>
    <script src="<?= base_url(); ?>assets/js/sweetalert2.all.min.js"></script>
</body>
</html>

