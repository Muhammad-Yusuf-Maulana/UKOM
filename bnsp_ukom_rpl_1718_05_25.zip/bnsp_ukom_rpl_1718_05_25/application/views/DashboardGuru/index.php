<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/css/style.css">
    <title><?= $judul; ?></title>
    <link rel="stylesheet" href="<?= base_url(); ?>assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vendor/fontawesome-free-5.12.0-web/css/all.min.css">
</head>
<body>
    <div class="container p-5">

        <form class="container" action="" method="get">
            <div class="row align-items-end">
                <div class="form-group">
                    <label for="nama" class="form-label form-label-sm">Search</label>
                    <input type="text" name="q" class="form-control form-control-sm" value="<?= set_value('q') ?>">
                </div>
            </div>
            <div class="row align-items-end">
                <div class="form-group">
                    <label class="form-label form-label-sm">Sort By :</label>
                    <div class="d-flex">
                        <select class="custom-select form-control-sm mr-1" name="field">
                            <option>-</option> 
                            <option value="kode">Kode</option>
                            <option value="nama">Nama</option>
                        </select>
                        <select class="custom-select form-control-sm mx-1" name="sortby">
                            <option>-</option>
                            <option value="ASC">ASC</option> 
                            <option value="DESC">DESC</option>
                        </select>
                    </div>
                </div>
                <div class="ml-auto form-group">
                    <button type="submit" class="btn btn-primary btn-sm">Submit</button>
                </div>
            </div>
        </form>

        <hr>
        
        <form class="container" action="" method="post">
            <div class="row align-items-end">
                <div class="form-group mr-2">   
                <label for="nama_mapel" class="form-label">Jurusan</label>
                    <select name="id_kategori" id="id_kategori" class="form-control">
                        <option value="">--- Pilih Jurusan ----</option>
                        <?php foreach($listnama as $ls) : ?>
                        <option value="<?= $ls['id'];?>"><?= $ls['nama'];?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group ml-2">
                <label for="nama_mapel" class="form-label">Kelas</label>
                    <select name="id_kategori" id="id_kategori" class="form-control">
                        <option value="">--- Pilih Kelas ----</option>
                        <option value="1">MAKANAN</option>
                    </select> 
                </div>
                <div class="ml-auto form-group">
                    <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>
                </div>
            </div>          
        </form>
  
        <div class="table-responsive">
            <table class="table table-striped table-borderless table-hover">
                <thead class="apes-thead">
                    <td>No.</td>
                    <td>Jurusan</td>
                    <td>Kelas</td>
                    <td>Nama</td>
                    <td>Aksi</td>
                </thead>
                <tbody class="text-center">
                    <?php $no = 1 ?>
                    <?php foreach( $list as $row ) : ?>  
                    <tr> 
                        <td><?= $no; ?></td> 
                        <td><?php echo $row['nama_jurusan']; ?></td>
                        <td><?php echo $row['nama_kelas']; ?></td>
                        <td><?php echo $row['nama_murid']; ?></td>
                        <td>
                            <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#detailModal<?php echo $row['id_jurusan']; ?>">EDIT</button> -->

                            <a href="" class="btn btn-primary">Detail</a>
                            <a href="<?= base_url(); ?>Guru/hapus/<?= $row['id_nilai'];?>" class="btn btn-danger">Hapus</a>
                        </td>
                    </tr>
                    <?php $no++; ?>
                        <div class="modal fade" id="addModal" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content p-2">
                                    <div class="modal-header">
                                        <h5 class="modal-title text-apes-primary">Tambah Mata Pelajaran</h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <i class="fas fa-times"></i>
                                        </button> 
                                    </div>
                                    <form class="container" action="<?= base_url(); ?>guru" method="post" enctype="multipart/form-data">
                                        <div class="modal-body">
                                                    <input type="text" name="id_guru" value="<?= $this->session->userdata('id');?>" class="form-control form-control-sm">
                                                    <input type="text" name="nh_pengetahuan" value="B" class="form-control form-control-sm">
                                                    <input type="text" name="nh_keterampilan" value="B" class="form-control form-control-sm">
                                            <div class="row">
                                            <label for="nama_mapel" class="form-label text-primary">Info Nilai</label>
                                                <div class="form-group col-md-12">
                                                <label for="id_murid" class="form-label form-label-sm">Nama</label>
                                                    <select name="id_murid" id="id_kategori" class="form-control">
                                                        <option value="">--- Pilih Murid ----</option>
                                                        <?php foreach($listnama as $ls) : ?>
                                                        <option value="<?= $ls['id'];?>"><?= $ls['nama'];?></option>
                                                        <?php endforeach; ?>   
                                                    </select>
                                                </div>
                                                <div class="form-group col-md-12">
                                                <label for="id_sub_mapel" class="form-label form-label-sm">Sub Mapel</label>
                                                    <select name="id_sub_mapel" id="id_kategori" class="form-control">
                                                        <option value="">--- Pilih Sub Mapel ----</option>
                                                        <?php foreach($listsubmapel as $lsm) : ?>
                                                        <option value="<?= $lsm['id'];?>"><?= $lsm['nama'];?></option>
                                                        <?php endforeach; ?>   
                                                    </select>
                                                </div>
                                                <div class="form-group col-md-12">
                                                <label for="nama" class="form-label form-label-sm">Jenis</label>
                                                    <select name="jenis" id="id_kategori" class="form-control">
                                                        <option value="">--- Pilih Jenis Nilai ----</option>
                                                        <option value="ULHAR">ULHAR</option>
                                                        <option value="PTS">PTS</option>
                                                        <option value="PAS">PAS</option>
                                                        <option value="UKK">UKK</option>
                                                        </select>
                                                </div>
                                                <div class="form-group col-md-12">
                                                    <label for="nama" class="form-label form-label-sm">Tahun Ajaran</label>
                                                    <input type="text" name="tahun_ajaran" class="form-control form-control-sm">
                                                </div>

                                            <label for="nama_mapel" class="form-label text-primary">Nilai</label>
                                                <div class="form-group col-md-12">
                                                    <label for="nilai_pengetahuan" class="form-label form-label-sm">Nilai Pengetahuan</label>
                                                    <input type="text" name="nilai_pengetahuan" class="form-control form-control-sm">
                                                </div>
                                                <div class="form-group col-md-12">
                                                    <label for="nilai_keterampilan" class="form-label form-label-sm">Nilai Ketrampilan</label>
                                                    <input type="text" name="nilai_keterampilan" class="form-control form-control-sm">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary rounded">Submit</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </tbody> 
            </table> 
        </div>

        <!-- <form class="container" action="" method="post">
            <div class="row align-items-end">
                <div class="form-group ml-2">
                    <form action="" method="post" class="form-inline my-2 my-lg-0">
                        <input class="form-control mr-sm-2" name="keyword" mr-sm-2" type="search" placeholder="Search..." aria-label="Search">
                        <button class="btn btn-outline-primary my-2 my-sm-0" type="submit">Search</button>
                    </form>
                </div>
            </div>          
        </form> -->

        

        
        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addModal">
        <i class="fas fa-plus"></i>
        Tambah Data</button>

        
    </div>
</body>
</html>
