    <div class="container pt-5 mt-5" style="min-height: 700px;">
        <div class="row">
            <div class="col-md-6" style="min-height: 300px;">
                <div class="d-flex justify-content-center " style="height: 70%;">
                    <img src="<?= base_url(); ?>assets/img/icon/user.png" alt="pict" style="width: 200px;">
                </div>
                <div class="d-flex justify-content-center align-items-center" style="height: 30%;">
                    <center> 
                        <!-- <a href="#" class="btn btn-primary" style="width: 200px;">Edit Profile</a> -->
                        <button type="button" class="btn btn-apes-primary" style="width: 200px;">Edit Profile</button>
                    </center>    
                </div>
            </div>
            <div class="col-md-6" style="min-height: 300px;">
                <div class="table-responsive apes-bg-seccondary p-3" style="height: 70%; border-radius: 8px 8px 0px 0px">
                    <table>
                        <tr>
                            <td>Nama</td>
                            <td>:</td> 
                            <td>3</td>
                        </tr>
                        <tr>
                            <td>NISN</td>
                            <td>:</td>
                            <td>6</td>
                        </tr>
                        <tr>
                            <td>Tempat, TGL Lahir</td>
                            <td>:</td>
                            <td>6</td>
                        </tr>
                        <tr>
                            <td>Alamat</td>
                            <td>:</td>
                            <td>6</td>
                        </tr>
                    </table>
                </div>
                <div class="apes-bg-primary" style="height: 30%; border-radius: 0px 0px 8px 8px">
                        test
                </div>
            </div>
        </div>

        <div class="table-responsive mt-5">
            <table class="table table-striped table-borderless table-hover">
                <thead class="apes-thead">
                    <td>No.</td>
                    <td>Mata Pelajaran</td>
                    <td>Pengetahuan</td>
                    <td>Keterampilan</td>
                    <td>Nilai Akhir</td>
                    <td>Predikat</td>
                </thead>
                <tbody class="text-center">
                <tr>
                    <td>1.</td>
                    <td>Matematika</td>
                    <td>70</td>
                    <td>70</td>
                    <td>70</td>
                    <td>C</td>
                </tr>
                </tbody>
            </table>
        </div> 

    </div>

    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        } );
    </script>

    <script src="<?= base_url(); ?>assets/js/btn.delete.sweetalert.js"></script>
    <script src="<?= base_url(); ?>assets/js/sweetalert2.all.min.js"></script>
</body>
</html>

