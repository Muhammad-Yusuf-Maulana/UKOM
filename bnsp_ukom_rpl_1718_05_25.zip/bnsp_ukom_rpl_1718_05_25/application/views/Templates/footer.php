  <script src="<?= base_url() ?>assets/js/fontawesome.js" charset="utf-8"></script>
  <script src="<?= base_url('assets/js/jquery-3.4.1.min.js') ?>"></script>
  <script src="<?= base_url('assets/js/popper.min.js') ?>"></script>
  <script src="<?= base_url('assets/js/bootstrap.min.js') ?>"></script>
</body>
</html>
