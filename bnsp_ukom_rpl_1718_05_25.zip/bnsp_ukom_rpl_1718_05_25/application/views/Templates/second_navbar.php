<?php if( $this->session->userdata('role')== 'Administrator' ) : ?>
  <nav class="navbar sticky-top apes-bg-seccondary">
    <div class="container justify-content-center">
        <ul class="nav">
            <li class="nav-item">
              <a href="<?= base_url('dashboard/admin/jurusan') ?>" class="apes-nav-link nav-link">Jurusan</a>
            </li>
            <li class="nav-item">
              <a href="#" class="apes-nav-link nav-link">Kelas</a>
            </li>
            <li class="nav-item">
              <a href="<?= base_url('dashboard/admin/mapel') ?>" class="apes-nav-link nav-link">Mapel</a>
            </li>
            <li class="nav-item">
              <a href="#" class="apes-nav-link nav-link">Pengguna</a>
            </li>
            <li class="nav-item">
              <a href="#" class="apes-nav-link nav-link">Nilai</a>
            </li>
        </ul>
    </div>
</nav>
    <?php elseif( $this->session->userdata('role')== 'Guru' ) : ?>
      <nav class="navbar sticky-top apes-bg-seccondary">
          <div class="container justify-content-center">
              <ul class="nav">
                  <li class="nav-item">
                    <h2 class="text-center text-primary">SELAMAT DATANG, GURU</h2>
                  </li>
              </ul>
          </div>
      </nav>
      <?php elseif( $this->session->userdata('role')== 'Murid' ) : ?>
      <nav class="navbar sticky-top apes-bg-seccondary">
          <div class="container justify-content-center">
              <ul class="nav">
                  <li class="nav-item">
                    <!-- <a href="#" class="apes-nav-link nav-link">Jurusan</a> -->
                    <h2 class="text-center text-primary">SELAMAT DATANG, MURID</h2>
                  </li>
              </ul>
          </div>
      </nav>
    <?php endif;?>   