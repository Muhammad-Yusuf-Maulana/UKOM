<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/css/style.css">
    <title><?= $title ?></title>
    <link rel="stylesheet" href="<?= base_url(); ?>assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/vendor/fontawesome-free-5.12.0-web/css/all.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>assets/css/animate.css">
</head>
<body>
<?php if( $this->session->userdata('role')== 'Administrator' ) : ?>
    <nav class="navbar apes-bg-primary">
        <div class="container">
            <div class="mx-2">
                <a href="<?= base_url(); ?>Profile/admin" class="fas fa-user-circle text-light fa-3x"></a>
            </div>
            <div class="mr-auto text-light">
                <p class="p-0 m-0 font-weight-bolder">
                  <?= $this->session->userdata('username') ?>
                </p>
                <p class="p-0 m-0">
                  <?= $this->session->userdata('role') ?>
                </p>
            </div>
            <div class="">
              <a href="<?= base_url('signout');?>" class="btn btn-light">
                <i class="fas fa-power-off text-danger"></i>
              </a>
            </div>
        </div>
    </nav>
<?php elseif( $this->session->userdata('role')== 'Guru' ) : ?>
    <nav class="navbar apes-bg-primary">
        <div class="container">
            <div class="mx-2">
                <a href="<?= base_url(); ?>Profile/guru" class="fas fa-user-circle text-light fa-3x"></a>
            </div>
            <div class="mr-auto text-light">
                <p class="p-0 m-0 font-weight-bolder">
                  <?= $this->session->userdata('nama'); ?>
                </p>
                <p class="p-0 m-0">
                  <?= $this->session->userdata('role'); ?>
                </p>
            </div>
            <div class="">
              <a href="<?= base_url('signout');?>" class="btn btn-light">
                <i class="fas fa-power-off text-danger"></i>
              </a>
            </div>
        </div>
    </nav>
<?php elseif( $this->session->userdata('role')== 'Murid' ) : ?>
    <nav class="navbar apes-bg-primary">
        <div class="container">
            <div class="mx-2">
                <a class="fas fa-user-circle text-light fa-3x"></a>
            </div>
            <div class="mr-auto text-light">
                <p class="p-0 m-0 font-weight-bolder">
                  <?= $this->session->userdata('nama') ?>
                </p>
                <p class="p-0 m-0">
                  <?= $this->session->userdata('role') ?>
                </p>
            </div>
            <div class="">
              <a href="<?= base_url('signout');?>" class="btn btn-light">
                <i class="fas fa-power-off text-danger"></i>
              </a>
            </div>
        </div>
    </nav>
    <?php endif;?>   
