<!-- Modal -->
<div class="modal fade" id="modallogin" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title text-center" id="exampleModalLabel">LOGIN</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form class="form-signin" action="<?php echo base_url().'home/auth'?>" method="post">
                            <label for="email" class="sr-only">Email</label>
                            <input type="email" id="email" name="email" class="form-control"
                                style="margin-bottom: 15px !important; margin-top: 15px !important;"
                                placeholder="Email / Username...">
                            <label for="pass" class="sr-only">Password</label>
                            <input type="password" id="pass" name="pass" class="form-control"
                                style="margin-bottom: 15px !important;" placeholder="Password...">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox" value="remember-me"> Remember me 
                                </label>
                            </div>
                            <button class="btn btn-primary btn-block" type="submit">Sign
                                in</button>
                            <br />
                        </form>
                        <p class="text-center">Belum Bisa MAMAM ? <a href="<?= base_url();?>Regis_umum"> Daftar!</a></p>
                    </div>
                </div>
            </div>
        </div>



        <button data-aos="fade-up" data-aos-duration="2500" data-aos-delay="800" type="button" style="padding-left: 30px; padding-right: 30px; font-weight: bold;" class="btn btn-primary" data-toggle="modal" data-target="#modallogin">LOGIN</button>
