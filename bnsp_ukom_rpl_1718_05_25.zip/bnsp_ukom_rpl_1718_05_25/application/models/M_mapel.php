<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_mapel extends MY_model {

  public function get($data)
  {
    if ($this->input->get('field') === '-' || $this->input->get() == null) {
      return $this->db->get('tb_mapel')->result_array();
    } else {
      $this->db->order_by($data['field'], $data['sortby']);
      return $this->db->get('tb_mapel')->result_array();
    }

  }

  public function search($data)
  {
    if ($data['field'] === '-' || $data['field'] == null) { 
      $this->db->like('nama', $data['q']);
      return $this->db->get('tb_mapel')->result_array();
    } else {
      $this->db->order_by($data['field'], $data['sortby']);
      $this->db->like('nama', $data['q']);
      return $this->db->get('tb_mapel')->result_array();
    }

  }

  public function searchandsort($data)
  {
    $this->db->like('nama', $data['q']);
    $this->db->order_by('kode', 'DESC');
    var_dump($data);
    // return $this->db->get('tb_mapel')->result_array();
  }

  public function update($data)
  {
    $id = $data['id'];
    $data = [
      'kode' => $data['kode_mapel'],
      'nama' => $data['nama_mapel']
    ];
    $this->db->where('id', $id);

    if ($this->db->update('tb_mapel', $data) == true) {
      $message = "<div class='alert alert-success'>
        Data berhasil diubah!
      </div>";
      $this->session->set_flashdata('message', $message);
      redirect(base_url('dashboard/admin/mapel'));
    } else {
      $message = "<div class='alert alert-danger'>
        Data gagal diubah!
      </div>";
      $this->session->set_flashdata('message', $message);
      redirect(base_url('dashboard/admin/mapel'));
    }
  }

  public function add($data)
  {
    $data = [
      'kode' => $data['kode_mapel'],
      'nama' => $data['nama_mapel']
    ];
    $insert = $this->db->insert('tb_mapel', $data);
    if ($insert == true) {
      $message = "<div class='alert alert-success'>
        Data berhasil dimasukkan!
      </div>";
      $this->session->set_flashdata('message', $message);
      redirect(base_url('dashboard/admin/mapel'));
    } else {
      $message = "<div class='alert alert-danger'>
        Data gagal dimasukkan!
      </div>";
      $this->session->set_flashdata('message', $message);
      redirect(base_url('dashboard/admin/mapel'));
    }
  }

  public function delete($id)
  {
    $this->db->where('id', $id);
    if ($this->db->delete('tb_mapel') == true) {
      $message = "<div class='alert alert-success'>
        Data berhasil dihapus!
      </div>";
      $this->session->set_flashdata('message', $message);
      redirect(base_url('dashboard/admin/mapel'));
    } else {
      $message = "<div class='alert alert-success'>
        Data gagal dihapus!
      </div>";
      $this->session->set_flashdata('message', $message);
      redirect(base_url('dashboard/admin/mapel'));
    }
  }

}
