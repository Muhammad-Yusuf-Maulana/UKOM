<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_guru extends MY_model {

  public function get()
  {
    return $this->db->get('tb_bidang_studi')->result_array();
  }

  public function getNama()
  {
    $this->db->where('id_kelas', $this->session->userdata('id_kelas'));
    $this->db->where('id_jurusan', $this->session->userdata('id_jurusan'));
    return $this->db->get('tb_murid')->result_array();
  }
  
  public function getSubMapel()
  {
    $this->db->where('id_mapel', $this->session->userdata('id_mapel'));
    return $this->db->get('tb_sub_mapel')->result_array();
  }

  public function getMapel()
  {
    $this->db->where('id', $this->session->userdata('id_mapel'));
    return $this->db->get('tb_mapel')->result_array();
  }
  public function inputNilai() 
    {
    	$data = [
             
            "id_sub_mapel" => $this->input->post('id_sub_mapel', true),
            "id_guru" => $this->input->post('id_guru', true),
            "id_murid" => $this->input->post('id_murid', true),
            "nilai_pengetahuan" => $this->input->post('nilai_pengetahuan', true),
            "nilai_keterampilan" => $this->input->post('nilai_keterampilan', true),
            "nh_pengetahuan" => $this->input->post('nh_pengetahuan', true),
            "nh_keterampilan" => $this->input->post('nh_keterampilan', true),
            "jenis" => $this->input->post('jenis', true),
            "tahun_ajaran" => $this->input->post('tahun_ajaran', true)

    	];  
 
        $this->db->insert('tb_nilai', $data); 
    }

}
