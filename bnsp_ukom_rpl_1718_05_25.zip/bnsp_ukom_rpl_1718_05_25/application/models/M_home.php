<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_home extends CI_Model {

	public function getAdminByUsername($username)
  {
    $this->db->where('username', $username);
    return $this->db->get('v_user')->row_array();
  }

  public function getGuruByUsername($username)
  {
    $this->db->where('username', $username);
    return $this->db->get('v_profile_guru')->row_array();
  }
  public function getMuridByUsername($username)
  {
    $this->db->where('username', $username);
    return $this->db->get('v_profile_murid')->row_array(); 
  }
}
 