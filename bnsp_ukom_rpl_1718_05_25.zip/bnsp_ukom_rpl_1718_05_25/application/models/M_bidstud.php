<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_bidstud extends MY_model {

  public function get()
  {
      return $this->db->get('tb_bidang_studi')->result_array();
  }

}
