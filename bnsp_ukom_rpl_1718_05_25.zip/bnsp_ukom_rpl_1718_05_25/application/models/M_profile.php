<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_profile extends MY_model {

  public function editGuru()
  {
        $data = [
            "id_mapel" => $this->input->post('id_mapel', true),
            "id_kelas" => $this->input->post('id_kelas', true),
            "id_jurusan" => $this->input->post('id_jurusan', true),
            "id_user" => $this->input->post('id_user', true),
            "nip" => $this->input->post('nip', true),
            "nama" => $this->input->post('nama', true),
    		"alamat" => $this->input->post('alamat', true)
						
    		]; 
		
		$config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'jpg|jpeg|png';
        $config['file_name'] = $this->input->post('id'); 

        $this->load->library('upload', $config);

        if( ! $this->upload->do_upload('foto') ) {
            $error = ['error' => $this->upload->display_errors()];
            $this->load->view('Profile/index', $error);
        } else {
            $upload_data = $this->upload->data();
            $file_name = $upload_data['file_name'];
            $data['foto'] = 'uploads/'.$file_name;
            $this->db->where('id', $this->input->post('id'));
            if($this->db->update('tb_guru', $data)) {
                // redirect('home');
            } 
        }

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('tb_guru', $data);
  }

}
