<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_murid extends CI_Model {

    public function get($data)
    {
        if ($this->input->get('field') === '-' || $this->input->get() == null) {
            $this->db->where('id_nilai');
        return $this->db->get('v_nilai')->result_array();
        } else {
            $this->db->where('id_nilai');
        $this->db->order_by($data['field'], $data['sortby']);
        return $this->db->get('v_nilai')->result_array();
        }

    }

  public function search($data)
    {
        if ($data['field'] === '-' || $data['field'] == null) {
            $this->db->where('id_nilai') ;
        $this->db->like('nama_murid', $data['q']);
        return $this->db->get('v_nilai')->result_array();
        } else {
            $this->db->where('id_nilai');
        $this->db->order_by($data['field'], $data['sortby']);
        $this->db->like('nama_murid', $data['q']);
        return $this->db->get('v_nilai')->result_array();
        }
 
    }
    

    function listNilai(){

        // $this->db2->where('nama_kategori', 'MAKANAN');
     
        $query = $this->db->query('SELECT * FROM v_nilai WHERE id_nilai')->result_array();
        $query = $this->db->get('v_nilai')->result_array();
        return $query;
    }

    function getDataMurid(){

        // $this->db2->where('nama_kategori', 'MAKANAN');
        // $query = $this->db->query("SELECT * FROM tb_")
        $query = $this->db->get('v_nilai')->result_array();
        return $query;
    }
    
    public function hapusData($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('tb_nilai');
    } 

    public function getdataById($id) 
	{ 

		return $this->db->get_where('v_nilai', ['id_jurusan' => $id])->row_array();

    }
    
    // public function getdetail() 
	// {
    //     $pelanggan= 'PELANGGAN';
    //     $where = ['nama_level !='=> $pelanggan];
    //     return $this->db2->get_where('v_user',$where)->result_array();
    // }
    // public function cariData() {

    //     $keyword = $this->input->post('keyword', true);
    //     $this->db2->like('nama_menu', $keyword);
    //     $this->db2->or_like('harga', $keyword);
    //     $this->db2->or_like('status_menu', $keyword);

    //     return $this->db2->get('tb_menu')->result_array();
    // }

    // public function tambah()
	// {
    //     $data = [
    // 				"id_kategori" => $this->input->post('id_kategori', true),
    //                 "nama_menu" => $this->input->post('nama_menu', true),
    //                 "harga" => $this->input->post('harga', true),
    //                 "status_menu" => $this->input->post('status_menu', true),
    //                 "deskripsi" => $this->input->post('deskripsi', true)
    // 			];   

    // 	$config['upload_path'] = './uploads/'; 
    //     $config['allowed_types'] = 'jpg|jpeg|png';
    //     $config['file_name'] = $this->input->post('id');

    //     $this->load->library('upload', $config);

    //     if( ! $this->upload->do_upload('foto') ) {
    //         $error = ['error' => $this->upload->display_errors()];
    //         $this->load->view('Menu/makanan', $error);
    //     } else {
    //         $upload_data = $this->upload->data();
    //         $file_name = $upload_data['file_name'];
    //         $data['foto'] = 'uploads/'.$file_name;
    //         if($this->db2->insert('tb_menu', $data)) {
    //             redirect('menu');
    //         }
    //     }
    // }
    public function ubahData()
	{
        $data = [
            "nama_menu" => $this->input->post('nama_menu', true),
            "status_menu" => $this->input->post('status_menu', true),
    		"id_kategori" => $this->input->post('id_kategori', true),
    		"harga" => $this->input->post('harga', true),
    		"deskripsi" => $this->input->post('deskripsi', true)
    		// "foto" => $this->input->post('foto', true)
						
    		]; 
		
		$config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'jpg|jpeg|png';
        $config['file_name'] = $this->input->post('id');

        $this->load->library('upload', $config);

        if( ! $this->upload->do_upload('foto') ) {
            $error = ['error' => $this->upload->display_errors()];
            $this->load->view('Menu/makanan', $error);
        } else {
            $upload_data = $this->upload->data();
            $file_name = $upload_data['file_name'];
            $data['foto'] = 'uploads/'.$file_name;
            $this->db2->where('id', $this->input->post('id'));
            if($this->db2->update('tb_menu', $data)) {
                redirect('menu');
            } 
        }

        $this->db2->where('id', $this->input->post('id'));
        $this->db2->update('tb_menu', $data);
    }
   
}
