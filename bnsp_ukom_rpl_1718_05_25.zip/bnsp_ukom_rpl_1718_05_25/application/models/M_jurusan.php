<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_jurusan extends MY_model {

  public function get($data)
  {
    if ($data['qbid'] === '-' || $data['qbid'] == null) {

    } else {
      if ($this->input->get('field') === '-' || $this->input->get() == null) {
        return $this->db->get('v_jurusan')->result_array();
      } else {
        $this->db->order_by($data['field'], $data['sortby']);
        return $this->db->get('v_jurusan')->result_array();
      }
    }
 
  }

  public function search($data)
  {
    if ($data['field'] === '-' || $data['field'] == null) {
      $this->db->like('nama', $data['q']);
      return $this->db->get('v_jurusan')->result_array();
    } else {
      $this->db->order_by($data['field'], $data['sortby']);
      $this->db->like('nama', $data['q']);
      return $this->db->get('v_jurusan')->result_array();
    }

  }

  public function update($data)
  {
    $id = $data['id'];
    $data = [
      'kode' => $data['kode_jurusan'],
      'nama' => $data['nama_jurusan']
    ];
    $this->db->where('id', $id);

    if ($this->db->update('tb_jurusan', $data) == true) {
      $message = "<div class='alert alert-success'>
        Data berhasil diubah!
      </div>";
      $this->session->set_flashdata('message', $message);
      redirect(base_url('dashboard/admin/jurusan'));
    } else {
      $message = "<div class='alert alert-danger'>
        Data gagal diubah!
      </div>";
      $this->session->set_flashdata('message', $message);
      redirect(base_url('dashboard/admin/jurusan'));
    }
  }

  public function add($data)
  {
    $data = [
      'kode' => $data['kode_jurusan'],
      'nama' => $data['nama_jurusan'],
      'id_bidstud' => $data['bidang_studi']
    ];
    $insert = $this->db->insert('tb_jurusan', $data);
    if ($insert == true) {
      $message = "<div class='alert alert-success'>
        Data berhasil dimasukkan!
      </div>";
      $this->session->set_flashdata('message', $message);
      redirect(base_url('dashboard/admin/jurusan'));
    } else {
      $message = "<div class='alert alert-danger'>
        Data gagal dimasukkan!
      </div>";
      $this->session->set_flashdata('message', $message);
      redirect(base_url('dashboard/admin/jurusan'));
    }
  }

  public function delete($id)
  {
    $this->db->where('id', $id);
    if ($this->db->delete('tb_jurusan') == true) {
      $message = "<div class='alert alert-success'>
        Data berhasil dihapus!
      </div>";
      $this->session->set_flashdata('message', $message);
      redirect(base_url('dashboard/admin/jurusan'));
    } else {
      $message = "<div class='alert alert-success'>
        Data gagal dihapus!
      </div>";
      $this->session->set_flashdata('message', $message);
      redirect(base_url('dashboard/admin/jurusan'));
    }
  }

}
